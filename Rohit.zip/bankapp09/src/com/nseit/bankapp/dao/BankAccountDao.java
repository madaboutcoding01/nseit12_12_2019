package com.nseit.bankapp.dao;

import java.util.List;

public class BankAccountDao implements IBankAccountDao {

	@Override
	public boolean addAccount(Object account) {
		return false;
	}

	@Override
	public Object getAccountByAccNo(int accNo) {
		return null;
	}

	@Override
	public List getAllAccounts() {
		return null;
	}

}
