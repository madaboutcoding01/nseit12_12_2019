package basicMustKnow;

import java.util.HashSet;

public class Main {

	public static void main(String[] args) {
		String name1="Rahil";
		String name2=new String("Rahil");
		System.out.println("name1.hashCode() "+name1.hashCode());
		System.out.println("name2.hashCode() "+name2.hashCode());
		
		System.out.println("name1==name2 "+name1==name2);
		System.out.println("name1.equals(name2) "+name1.equals(name2));
		
		Person p1=new Person(1,"Rhina");
		Person p2=new Person(1,"Rhina");
		
		System.out.println("p1.hashCode() "+p1.hashCode());
		System.out.println("p2.hashCode() "+p2.hashCode());
		
		System.out.println("p1==p2 "+(p1==p2));
		System.out.println("p1.equals(p2) "+p1.equals(p2));
		
//		Person p3=p1;//this==obj
		
		HashSet<Person> persons=new HashSet<>();
		persons.add(p1);
		persons.add(p2);
		persons.add(p2);
		persons.add(p2);
		persons.add(p2);
		System.out.println("persons :"+persons);
		
		
		
	}

}
