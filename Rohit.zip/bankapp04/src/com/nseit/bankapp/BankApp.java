package com.nseit.bankapp;
import java.util.Scanner;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;
public class BankApp {
	public static void main(String[] args) {
		BankAccount account=null;
		Scanner sc=new Scanner(System.in);
		while(true){
			System.out.println("Select options:");
			System.out.println("1. Create Account");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			int mainMenu=Integer.parseInt(sc.nextLine());
			double amount=0.0;
			switch(mainMenu){
			case 1:
				System.out.println("Select Type of Account");
				System.out.println("1 Saving Account");
				System.out.println("2 Salary Account");
				int accType=Integer.parseInt(sc.nextLine());
				System.out.println("Enter your accno");
				int accNo=Integer.parseInt(sc.nextLine());
				System.out.println("Enter your acc holder name");
				String accName=sc.nextLine();
				System.out.println("Enter opening balance");
				double balance=Double.parseDouble(sc.nextLine());
				switch(accType){
				case 1:			
						account=new SavingAccount(accNo, accName, balance);
						break;
				case 2:			
						account=new SalaryAccount(accNo, accName, balance);
						break;
				}
				break;
			case 2:
				System.out.println("Enter amount to be deposited");
				amount=Double.parseDouble(sc.nextLine());
				try {
					account.deposit(amount);
				} catch (Exception e) {
					System.out.println("While Deposit call");
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter amount to be withdraw");
				amount=Double.parseDouble(sc.nextLine());
				try {
					account.withdraw(amount);
				} catch (InsufficientBalanceException e) {
					System.out.println("While Withdraw call");
					e.printStackTrace();
				}			
				break;
			}
			System.out.println("Account Details :");
			System.out.println(account);
			System.out.println("To Exit enter 0");
			int exitLoop=Integer.parseInt(sc.nextLine());
			if(exitLoop==0)break;
		}
	}

}
