package com.nseit.bankapp.dao;

import java.sql.SQLException;
import java.util.List;

public interface IBankAccountDao<BankAccount> {

	boolean addAccount(BankAccount account) throws SQLException, Exception;

	boolean delete(BankAccount account) throws Exception;

	boolean updateDeposit(BankAccount account, double amount) throws Exception;

	boolean updateWitdraw(BankAccount account, double amount) throws Exception;

	boolean closeAccount(int accNo) throws Exception;

	List<BankAccount> findAll() throws Exception;

	BankAccount findById(int accNO) throws Exception;
}
