package com.nseit.bankapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BankApp {

	private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String USERNAME = "nseitdb";
	private static final String PASSWORD = "root";

	public static void main(String[] args) {

	//	dummy();

	}

	private static void dummy() {
		
		
		
		
		
		
	}

}
