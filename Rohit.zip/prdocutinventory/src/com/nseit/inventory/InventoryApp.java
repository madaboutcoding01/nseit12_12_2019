package com.nseit.inventory;

import java.util.Scanner;

import com.nseit.inventory.model.Product;

public class InventoryApp {

public static void main(String[] args) {
	
	
	Scanner sc=new Scanner(System.in);
	
	
	Product p=new Product(101,"Laptop",4500,1);
	Product pp=new Product(102,"Mobile",450,5);
	Product pp2=new Product(103,"PC",460,6);
	Product pp3=new Product(104,"earphone",1500,8);
	
	
	
	
	
	
	
}	
	
	
	
	
}
