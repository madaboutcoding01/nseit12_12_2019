package com.nseit.inventory.model;

public class Product {

	private int productid;
	private String productname;
	private double  price;
	private int quantity;
	
	
	public Product() {
	}


	public Product(int productid, String productname, double price, int quantity) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.price = price;
		this.quantity = quantity;
	}

	public void incQuantity(int Qt) {
		this.quantity +=Qt;
	}
	
	public void QuantityDec(int qnt) {
		this.quantity = Math.max(this.quantity-qnt, 0);
	}
	
	public int getQuantity(){
		return this.quantity;
	}
	

	
	
	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productname=" + productname + ", price=" + price + ", quantity="
				+ quantity + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
