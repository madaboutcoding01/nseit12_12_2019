package com.nseit.inventory.model;

import java.util.ArrayList;

public class ProductStack<AnyType> {

	private ArrayList<AnyType> buffer = new ArrayList<>();
	private int size = 0;
	private int top = -1;
	
	
	public ProductStack() {
		super();
	}

	public ProductStack(int size) {
		super();
		this.buffer = new ArrayList<>(size);
		this.size = size;
	}

	
	
	public String addProduct(Product p)
	{
		buffer.add(AnyType)  p);
		return "product Added";
		
	}

	
	
	
	
	
}
