package com.nseit.bankapp.model;

public interface IBankAccountService {
	
	
	
	
	
	
	
	

}
