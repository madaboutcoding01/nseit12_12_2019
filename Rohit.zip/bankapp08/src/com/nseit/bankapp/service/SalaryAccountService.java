package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class SalaryAccountService implements IBankAccountService{

	private BankAccountStack<SalaryAccount> accounts;
	
	public SalaryAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}

	@Override
	public String addAcount(String accName, double balance) {
		String msg="Failed To create new account ";
		msg=accounts.addAccount(new SalaryAccount(accName, balance));		
		return msg;
	}

	@Override
	public String getAllAccountDetails() {
		return accounts.getAccountDetails();
	}

	
}
