package com.nseit.paytm.service;

import com.nseit.bankapp.model.BankAccount;

public class PayTmFundTransfer {
	
	private BankAccount account1;

	public PayTmFundTransfer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PayTmFundTransfer(BankAccount account1) {
		super();
		this.account1 = account1;
	}

	public String transfer(double amount, BankAccount account2) throws Exception{
		StringBuilder sb=new StringBuilder();
		//sb.append(account1.withdraw(amount)+ " debited by "+amount);
		
		sb.append("<br/>")
		.append(account1.getAccNo())
		.append(" transfered amount ")
		.append(amount)
		.append(" transfered to ")
		.append(account2.getAccNo())
		.append("<br/>account 1 balance ")
		.append(account1.getBalance())
		.append("<br/>account2 balance ")
		.append(account2.getBalance());
		sb.append(account2.deposit(amount)+ " credited by "+amount);
		return sb.toString();
	}
	
}