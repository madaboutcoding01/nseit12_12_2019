package com.nseit.webdemo.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.paytm.service.PayTmFundTransfer;
import com.nseit.webdemo.service.BankAccountService;

/**
 * Servlet implementation class FundTransferController
 */
public class FundTransferController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		log("Fund Transfer Started");
		int accNo1=Integer.parseInt(request.getParameter("accNo1").trim());
		int accNo2=Integer.parseInt(request.getParameter("accNo2").trim());
		double amount=Double.parseDouble(request.getParameter("amount").trim());
		try
		{
		BankAccount ba1=BankAccountService.getAccount(accNo1);
		BankAccount ba2=BankAccountService.getAccount(accNo2);
		System.out.println(ba1);
		System.out.println(ba2);
		PayTmFundTransfer payTm=new PayTmFundTransfer(ba1);
		String msg=payTm.transfer(amount,ba2);
		request.setAttribute("msg",msg);
		System.out.println(msg);
		System.out.println(ba1);
		System.out.println(ba2);
		RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
		rd.forward(request, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		log("Fund Transfer Ended");
	}

}
