package com.nseit.webdemo.service;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.webdemo.dao.BankAccountDao;

public class BankAccountService {

	private static BankAccountDao dao=new BankAccountDao();
	public static BankAccount getAccount(int accNo) throws Exception {
		System.out.println("BAS "+accNo);
		return dao.getAccount(accNo);
	}

}
