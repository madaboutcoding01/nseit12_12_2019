package com.nseit.webdemo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class BankAccountDao {

//	private static final String FIND_BY_ID = "Select * FROM BANKACCOUNT WHERE ACCNO=?";
	private static final String FIND_BY_ID = "SELECT "
			+ " ACCNO,ACCNAME,BALANCE,ACCTYPE "
			+ " FROM BANKACCOUNT WHERE ACCNO=?";

	public BankAccount getAccount(int accNo) throws Exception {
		Connection connection=ConnectionUtil.getConnection();
		PreparedStatement select=connection.prepareStatement(FIND_BY_ID);
		select.setInt(1, accNo);
		ResultSet results=select.executeQuery();
		BankAccount account=null;	
		
		if(results.next()){
			final String accName=results.getString("accName");
			final double balance=results.getDouble("balance");
			if(results.getString("ACCTYPE").equals("SA")){
				account=new SavingAccount(accNo,accName,balance);
			}else if(results.getString("ACCTYPE").equals("SAL")){
				account=new SalaryAccount(accNo,accName,balance);
			}
			
			
		}
		connection.close();
		return account;
	}
	
//	public BankAccount getAccount(int accNo) throws Exception {
//		// return test(accNo);
//		Connection connection = ConnectionUtil.getConnection();
//		Statement select = connection.createStatement();
//		ResultSet results = select.executeQuery("select * from bankaccount");
//		BankAccount account = new SalaryAccount();
//		List<BankAccount> ba = new ArrayList<>();
//		while (results.next()) {
//			System.out.println("result.next started ");
//			account.setAccNo(accNo);
//			String accName = results.getString(2);
//			account.setAccName(accName);
//			double balance = results.getDouble(3);
//			account.setBalance(balance);
//			System.out.println("Account : " + account);
//			System.out.println("result.next ended ");
//		}
//		results.close();
//		select.close();
//		connection.close();
//		return account;
//	}
//
//	private BankAccount test(int accNo) throws Exception, SQLException {
//		System.out.println("DAO BAS " + accNo);
//		Connection connection = ConnectionUtil.getConnection();
//		PreparedStatement select = connection.prepareStatement(FIND_BY_ID);
//		select.setInt(1, accNo);
//		ResultSet results = select.executeQuery();
//		BankAccount account = new SalaryAccount();
//		account.setBalance(1478529);
//		while (results.next()) {
//			System.out.println(results.getInt(1));
//			System.out.println(results.getString(2));
//			System.out.println(results.getDouble(3));
//			System.out.println(results.getString(4));
//		}
//		results.close();
//		select.close();
//		connection.close();
//		return account;
//	}

}
