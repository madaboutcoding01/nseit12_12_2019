package com.nseit.webdemo.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
		
		try(PrintWriter out=response.getWriter())
		{
			System.out.println("Login controller call");
			String userName=request.getParameter("userName").trim();
			String password=request.getParameter("password").trim();
			RequestDispatcher rd = null;
			if (userName != null & password != null) {
				if (userName.equals("training") && password.equals("123456")) {
					rd = request.getRequestDispatcher("home.jsp");
				} else {
					rd = request.getRequestDispatcher("error.jsp");
				}
				rd.forward(request, response);
			}
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
