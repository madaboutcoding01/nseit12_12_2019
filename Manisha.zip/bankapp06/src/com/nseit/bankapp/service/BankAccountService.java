package com.nseit.bankapp.service;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankAccountService implements IBankAccountService {
	private List<BankAccount> accountlist = new LinkedList<>();

	public List<BankAccount> getAccounts() {
		return accountlist;
	}

	@Override
	public List<BankAccount> sortByAccName() {
		Collections.sort(accountlist, new SortByName());
		return accountlist;
	}

	@Override
	public List<BankAccount> sortByBal() {
		Collections.sort(accountlist, new SortByBalance());
		return accountlist;
	}

	@Override
	public double checkBalance(int accNo) {
		return findByAccno(accNo).getBalance();
	}

	@Override
	public String addAccount(String accName, double balance) {
		boolean test = accountlist.add(new SavingAccount(accName, balance));

		if (test) {
			return "Account Created";
		}
		return "Failed To Create";
	}

	@Override
	public String transaction(int accNo, double amount, String opType) {
		BankAccount account = findByAccno(accNo);
		String msg = accNo + "";
		switch (opType) {
		case "d":
			try {
				msg = msg + amount + "amount Credited.Balance Is" + account.deposit(amount);
			} catch (Exception e) {
				msg = "Transaction Failed For Deposite";
			}
			break;
		case "w":
			try {
				msg = msg + amount + "amount Debited.Balance Is" + account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg = "Transaction Failed For Withdraw";
			}

			break;
		}
		return msg;
	}

	@Override
	public String closeAccount(int accNo) {
		BankAccount account = findByAccno(accNo);
		if (accountlist.remove(account)) {
			return "Closed Account " + account;
		}
		return "Failed To Close Connection";
	}

	@Override
	public BankAccount findByAccno(int accNo) {
		for (BankAccount account : accountlist) {
			if (account.getAccNo() == accNo) {
				return account;
			}
		}
		return null;
	}
}
