package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.IBankAccountService;
import com.nseit.bankapp.service.SalaryAccountService;
import com.nseit.bankapp.service.SavingAccountService;

public class BankApp {

	public static void main(String[] args) {
//testBankAccountStack();

IBankAccountService service=new SavingAccountService();
service.addAccount("MAnisha", 50000);
System.out.println(service.getAllAccountDetails());


service=new SalaryAccountService();
service.addAccount("Helly", 80000);
System.out.println(service.getAllAccountDetails());
	}

	private static void testBankAccountStack() {
		BankAccountStack<BankAccount> stack=
						new BankAccountStack<>(5);
		stack.addAccount(new SavingAccount("Rajat", 10000.0));
		stack.addAccount(new SavingAccount("Ranjan", 10000.0));
		stack.addAccount(new SalaryAccount("Raj", 0.0));
		stack.addAccount(new SalaryAccount("Jatin", 41000.0));
		
		System.out.println(stack.getAccountDetails());
		stack.closeAccount(stack.getAccounts().get(3));
		System.out.println("After closure ");
		System.out.println(stack.getAccountDetails());
	}

}