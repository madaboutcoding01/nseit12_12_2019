package com.nseit.bankapp.model;

public interface IBankAccount extends IDeposit,IWithdraw {

}
