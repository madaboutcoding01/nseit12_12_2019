package com.nseit.bankapp.service;

import java.util.List;

public interface IBankAccountService<T> {

	String addAccount(String accName,double balance);
	T findById(int accNo);
	List<T> findAll();
}