package com.nseit.inventory.util;

public class CustomException extends  Exception  {

	public CustomException(String msg) {
		super(msg);
	}

}
