package com.nseit.inventory.service;

import java.util.LinkedList;
import java.util.List;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class ProductService implements IProduct{

	
	private ProductStack<Product> products;
	@Override
	public String addProduct(String pName, double price, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteProduct(int pid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateAddProduct(int pid, int quantity) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateRemoveProduct(int pid, int quantity) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int findByID(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Product findByAll(int accNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAllProductDetails() {
		return products.getProductDetails();
	}

	


	

}
