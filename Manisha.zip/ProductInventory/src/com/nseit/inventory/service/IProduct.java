package com.nseit.inventory.service;


import com.nseit.inventory.model.Product;

public interface IProduct 
{
String addProduct(String pName,double price,int quantity);
int deleteProduct(int pid);
int updateAddProduct(int pid,int quantity);
int updateRemoveProduct(int pid,int quantity);
int findByID(int id);
Product findByAll(int accNo);
String getAllProductDetails();
}
