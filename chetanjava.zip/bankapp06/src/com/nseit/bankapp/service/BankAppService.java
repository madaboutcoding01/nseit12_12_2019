package com.nseit.bankapp.service;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.IBankAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankAppService implements IBankAccountService
{
	List <BankAccount> accountList = new LinkedList<>();


	@Override
	public BankAccount findByAccNo(int accNo) {
		
		for (BankAccount account:accountList)
		{
			if (account.getAccNo()==accNo)
			{
				return account;
			}
		}
		return null;
	}
	@Override
	public List <BankAccount> getAccounts()
	{
		return accountList;
	}
	
	//sort by accName
		@Override
		public List<BankAccount> sortByAccName() {
			Collections.sort(accountList,new SortByName());
			return accountList;
		}
		//sort by balance
		@Override
		public List<BankAccount> sortByBal() {
			Collections.sort(accountList,new SortByBalance());
			return accountList;
		}
		@Override
		public double checkbalance(int accNo) 
		{
	
			return findByAccNo(accNo).getBalance();
		}
		@Override
		public String addAccount(String accName, double balance) {
			boolean test=
			accountList.add(new SavingAccount(accName, balance));
			if (test)
				return "Account Created";
			return "Failed to Create New Account";
		}
		@Override
		public String closeAccount(int accNo) {
			BankAccount account = findByAccNo(accNo);
			if (accountList.remove(account))
			{
				return "Closed account " + account;
			}
			return "Failed to close account";
		}
		@Override
		public String transaction(int accNo, double amount, String opType) {
			
		 BankAccount account = findByAccNo(accNo);
		 
		String msg = accNo + " ";
		 switch (opType) {
		case "d": try {
				msg =msg+amount+"amount credited , balance is:"+account.deposit(amount);
			} catch (Exception e) {
				msg = "transaction failed for deposit";
			}
			
			break;

		case "w":
			try {
				msg = msg + amount + " amount debited.Balance is " + account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg = "Transaction failed for withdraw";
			}

			break;
		}
		return msg;
		}
	
}
