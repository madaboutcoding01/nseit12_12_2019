package com.nseit.inventory.model;

public class Product {
	int productId;
	String pname;
	double price;
	int quantity;
	
	public Product (int productId ,String pname,double price,int quantity)
	{
		super();
		this.productId = productId;
		this.pname = pname;
		this.price = price;
		this.quantity = quantity;
		
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
	 
}
