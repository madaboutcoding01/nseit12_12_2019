package com.nseit.inventory.model;

import java.util.ArrayList;
import java.util.List;

public class ProductStack<AnyType> {
	private ArrayList<AnyType> buffer = new ArrayList();
	private int size = 0;
	private int top = -1;

	public ProductStack(int size) {
		super();
		this.buffer = new ArrayList(size);
		this.size = size;
	}

	public String addProduct(AnyType product) {
		if (buffer.add(product)) {
			top++;
			size = getCountOfTotalProduct();
			return "successfully added";

		}
		return "Failed to add product";
	}

	private int getCountOfTotalProduct() {

		return buffer.size();
	}

	public String deleteProduct(AnyType Product) {
		if (buffer.remove(Product)) {
			top--;
			size = getCountOfTotalProduct();
			return "product successfully deleted";
		}
		return null;
	}

	public String updateProduct(AnyType Product) {
		return null;

	}

	public String delete(AnyType pid) {
//		ArrayList<AnyType> id = findbyid(pid);
//		if (buffer.remove(pid)) {
//			top--;
//			size = getCountOfTotalProduct();
//			return "Product Closed.";
//		}
		return "failed to delete Product";

	}

	private String findbyid(int no)
	{
		StringBuilder sb = new StringBuilder();
		for (AnyType a:buffer)
		{
		sb.append(a.toString())
		.append("\n");
		}
		
	return sb.toString();
	}

	public List<AnyType> getProductId() {
		return buffer;
	}

}
