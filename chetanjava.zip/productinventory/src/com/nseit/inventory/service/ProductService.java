package com.nseit.inventory.service;


public class ProductService
{
//	private productstack <AnyType>

}
