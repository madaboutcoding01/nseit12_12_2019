package com.nseit.inventory.model;

import java.util.ArrayList;

public class ProductStack<AnyType> {
	private ArrayList<AnyType> buffer =new ArrayList<>();
	private int size=0;
	private int top=-1;
	public ProductStack(int size) {
		super();
		this.buffer=new ArrayList<>(size);
		this.size=size;
	}
	
	public String addAccount(AnyType product)
	{
		if(buffer.add(product)){
			top++;
			size=getCountOfTotalAccount();
			return "Successfully added";
		}
		return "Failed to add account";
		
	}
	public int getCountOfTotalAccount(){
		return buffer.size();
	}
	public String findAll(){
		StringBuilder sb=new StringBuilder();
		for(AnyType a:buffer){
			sb.append(a.toString()).append("\n");
		}
		return sb.toString();
	}

}
