package com.nseit.inventory.model;

import com.nseit.inventory.service.IProduct;

public class Product implements IProduct{
	private static int counter;
	private int pid;
	private String pname;
	private double price;
	private double quantity;
	static{
		counter=100;
	}
	{
		this.pid=++counter;
	}
	public Product(String pname,double price,double quantity){
		super();
		this.pname=pname;
		this.price=price;
		this.quantity=quantity;
		
		
		
	}
	
	@Override
	public String add(String pname, double price, double quantity) {
		
		return null;
	}

	@Override
	public int delete(String pid) {

		return 0;
	}

	@Override
	public String updateAdd(int pid, double quantity) {
	
		return null;
	}

	@Override
	public String updateRemove(int pid, double quantity) {
		
		return null;
	}

	@Override
	public String findId(int pid) {
	
		return null;
	}

	@Override
	public String findAll() {
	
		return null;
	}
	
	
	

}
