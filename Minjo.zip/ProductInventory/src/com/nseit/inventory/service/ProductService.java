package com.nseit.inventory.service;

import java.util.HashSet;
import java.util.Set;

import com.nseit.inventory.model.Product;

public class ProductService implements IProduct{

	private Set<Product> product=new HashSet<>();
	
	@Override
	public String add(String pname, double price, double quantity) {
		boolean test = product.add(new Product(pname,price,quantity));
		if (test)
			return "Product Added";
		return "Failed to Add Product";
		
	}

	@Override
	public int delete(String pid) {
		
		return 0;
	}

	@Override
	public String updateAdd(int pid, double quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateRemove(int pid, double quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findId(int pid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findAll() {
		Set<Product> productList = service.getAccounts();
		for(Product ba: productList){
			System.out.println(ba);
		}
		return null;
	}
	

}
