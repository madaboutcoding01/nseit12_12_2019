package com.nseit.inventory.service;

public interface IProduct {

	String add(String pname,double price,double quantity);
	int delete(String pid);
	String updateAdd(int pid,double quantity);
	String updateRemove(int pid,double quantity);
	String findId(int pid);
	String findAll();
	
}
