package com.nseit.inventory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.nseit.inventory.service.ProductService;

public class InventoryApp {

	public static void main(String[] args) {
		
		ProductService service= new ProductService();
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)))
		{
		String pname;
		double price;
		double quantity;
		System.out.println("Enter Product name ");
		pname = reader.readLine();
		
		System.out.println("Enter Product price");
		price = Double.parseDouble(reader.readLine());
		
		System.out.println("Enter Product Quantity");
		quantity = Double.parseDouble(reader.readLine());
		
		System.out.println(service.add(pname,price,quantity));
		}catch(Exception e){}

	}

}
