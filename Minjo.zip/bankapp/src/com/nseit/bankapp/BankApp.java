package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;

public class BankApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	//Create an BankAccount
BankAccount account1=new BankAccount();
		//default values accNo,accName,balance
BankAccount account2=new BankAccount(1001, "Manisha", 50000.00);

//short cut:sysout
System.out.println("Account1 details :");
System.out.println("Account Number :"+account1.getAccNo());
System.out.println("Account Name :"+account1.getAccName());
System.out.println("Account Balance :"+account1.getBalance());

System.out.println("Account2 details :");
System.out.println("Account Number :"+account2.getAccNo());
System.out.println("Account Name :"+account2.getAccName());
System.out.println("Account Balance :"+account2.getBalance());

System.out.println(account1);
System.out.println(account2);



	}

}
