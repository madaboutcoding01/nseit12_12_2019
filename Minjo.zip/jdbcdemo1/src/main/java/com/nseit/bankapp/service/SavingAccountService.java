package com.nseit.bankapp.service;

import java.util.List;

public class SavingAccountService implements IBankAccountService {

	public String addAccount(String accName, double balance) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object findById(int accNo) {
		// TODO Auto-generated method stub
		return null;
	}

	public List findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
