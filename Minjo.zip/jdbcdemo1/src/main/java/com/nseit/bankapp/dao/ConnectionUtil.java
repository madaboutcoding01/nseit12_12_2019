package com.nseit.bankapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil {
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:ORCL";
	private static final String USERNAME = "system";
	private static final String PASSWORD = "root";
	
	private static Connection connection;
	public static Connection getConnection()throws Exception{
		connection=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		if(!connection.isClosed()){
			return connection;
			
		}else{
			System.out.println("Failed to connect");
		}
		return null;
		
	}
}
