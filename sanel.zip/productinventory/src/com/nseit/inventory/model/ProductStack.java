package com.nseit.inventory.model;

import java.util.ArrayList;
import java.util.List;



public class ProductStack<AnyType> {
	private Product []accountArray=new Product[5];
	private ArrayList<AnyType> buffer=new ArrayList<>();
	private int size=0;
	private int top=-1;
	public ProductStack() {
		super();
		
	}
	public ProductStack(ArrayList<AnyType> buffer, int size) {
		super();
		this.buffer = buffer;
		this.size = size;
	}
	
	
	public String add(AnyType product){
		if(buffer.add(product)){
			top++;
			//size=getCountOFTotalAccount();
			return "Success fully added";			
		}
		return "Failed to add product";
	}
	public String delete(int pid){
		Product product=null;
		product=findId(pid);
		
		if(buffer.remove(product)){
			top--;
			return "succesfully deleted";
		}
		return "failed to delete";
	}
	//String update(AnyType product)
	//{
		
	//}
	public Product findId(int pid) {
		Product product=null;
		for(Product ba : accountArray){
			if(ba!=null&& ba.getpid()==pid){
				product=ba;
			}
		}
		return product;
	}
	//findAll:list/set
	public List<AnyType> findall(){
		return buffer;
	}
	

}
