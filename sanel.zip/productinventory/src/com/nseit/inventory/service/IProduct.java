package com.nseit.inventory.service;

import com.nseit.inventory.model.Product;

public interface IProduct {
String add(String pname,double price,int quantity);
String delete(int pid);
String updateAdd(int pid,int quantity);
String updateRemove(int pid,int quantity);
Product findId(int pid);
Product findAll();
}
