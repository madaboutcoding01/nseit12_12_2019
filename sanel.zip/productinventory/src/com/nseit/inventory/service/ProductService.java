package com.nseit.inventory.service;


import com.nseit.inventory.model.Product;

public class ProductService implements IProduct{

	@Override
	public String add(String pname, double price, int quantity) {
		
		return "";
	}

	@Override
	public String delete(int pid) {
	return "";
	}

	@Override
	public String updateAdd(int pid, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateRemove(int pid, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product findId(int pid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
