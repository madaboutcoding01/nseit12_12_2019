package com.nseit.inventory;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class InventoryApp {

	public static void main(String[] args) {
		ProductStack<Product> stack=
				   new ProductStack<>(5);
stack.add(new Product("hello", 120.00, 12));
stack.delete(12);

	}

}
