package com.nseit.bankapp.service;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankAccountService implements IBankAccountService {
	private Set<BankAccount> accountList=new HashSet<>();
	//findbyaccNO
		@Override
		public BankAccount findByAccNo(int accNo) {
			for(BankAccount account:accountList)
			{
				if(account.getAccNo()==accNo){
					return account;
				}
			}
			return null;
		}
		@Override
		public Set<BankAccount> getAccounts() {
			
			return accountList;
		}
		
		@Override
		public Set<BankAccount> sortByAccName() {
			SortedSet<BankAccount> sortedSet=new TreeSet<>(new SortByName());
			for(BankAccount ba:accountList)
			{
				sortedSet.add(ba);
			}
			return accountList;
		}
		
		@Override
		public Set<BankAccount> sortByBal() {
			SortedSet<BankAccount> sortedSet=new TreeSet<>(new SortByName());
			for(BankAccount ba:accountList)
			{
				sortedSet.add(ba);
			}
			return accountList;
		}
		
		@Override
		public double checkBalance(int accNo) {
		
			return findByAccNo(accNo).getBalance();
		}
		
		@Override
		public String addAccount(String accName, double balance) {
		boolean test=accountList.add(new SavingAccount(accName, balance));
		if(test)
			return "account created";
		return "Failed to create new account";
			
		}
		 
		public String closeAccount(int accNo){
			BankAccount account=findByAccNo(accNo);
			if(accountList.remove(account)){
				return "closed account"+account;
			
			}
			return "Failed to close account";
		}
		
		@Override
		public String transaction(int accNo, double amount, String opType) {
			BankAccount account=findByAccNo(accNo);
			String msg=accNo+"";
			switch(opType)
			{
			case "d":
				try {
					msg=msg+"amount cretedited.Balance is" +account.deposit(amount);
				} catch (Exception e) {
					msg="Transaction failed for deposit";
				}
				break;
			case "w":
				try {
					msg=msg+"amount debited.Balance is" +account.withdraw(amount);
				} catch (InsufficientBalanceException e) {
					
					msg="Transaction failed for withdraw";
				}
			}
			return msg;
		}
}
