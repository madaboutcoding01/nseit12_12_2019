package com.nseit.bankapp08.model;

import java.util.ArrayList;
import java.util.List;

public class BankAccountStack<AnyType> {
	private ArrayList<AnyType> buffer=new ArrayList<>();
	private int size=0;
	private int top=-1;
	public BankAccountStack() {
		super();
	}
	public BankAccountStack(int size) {
		super();
		this.buffer=new ArrayList<>(size);
		this.size = size;
	}
	public String addAccount(AnyType account){
		if(buffer.add(account)){
			top++;
			size=getCountOFTotalAccount();
			return "Success fully added";			
		}
		return "Failed to add account";
	}
	public int getCountOFTotalAccount(){
		return buffer.size();
	}
public String closeAccount(AnyType account){
	if(buffer.remove(account)){
		top--;
		size=getCountOFTotalAccount();
		return "Account closed";
	}
	return "Failed to close account";
} 

public String getAccountDetails(){
	StringBuilder sb=new StringBuilder();
	for(AnyType a:buffer){
		sb.append(a.toString())
		.append("\n");
	}
	return sb.toString();
}	
public List<AnyType> getAccounts(){
	return buffer;
}
}
