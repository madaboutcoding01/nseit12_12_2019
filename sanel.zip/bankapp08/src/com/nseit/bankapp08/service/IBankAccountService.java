package com.nseit.bankapp08.service;

public interface IBankAccountService {
	 String addAccount(String accName,double balance);
	String getAllAccountDetails();

}
