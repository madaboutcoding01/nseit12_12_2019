package com.nseit.bankapp08.service;

import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp08.model.BankAccountStack;

public class SavingAccountService implements IBankAccountService {
  
	private BankAccountStack<SavingAccount> accounts;
	public SavingAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}
	@Override
	public String addAccount(String accName, double balance) {
	String msg="Failed to create new account";
	msg=accounts.addAccount(new SavingAccount(accName, balance));

	return msg;
	}
	@Override
	public String getAllAccountDetails() {
		// TODO Auto-generated method stub
		return accounts.getAccountDetails();
	}
	

}
