package com.nseit.bankapp08.service;

import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp08.model.BankAccountStack;

public class SalaryAccountService implements IBankAccountService{
	BankAccountStack<SalaryAccount> accounts;
	public SalaryAccountService() {
		super();
		accounts=new BankAccountStack<>();
		
	}
	@Override
	public String addAccount(String accName, double balance) {
		String msg="Failed to create new account";
		msg=accounts.addAccount(new SalaryAccount(accName, balance));
	
		return msg;
	}
	@Override
	public String getAllAccountDetails() {
		return accounts.getAccountDetails();
	}

}
