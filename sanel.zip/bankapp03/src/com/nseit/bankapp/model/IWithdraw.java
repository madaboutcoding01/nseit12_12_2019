package com.nseit.bankapp.model;

import com.nseit.bankapp.util.InsufficientBalanceException;

public interface IWithdraw {
	public  double withdraw(double amount) throws Exception;
}
