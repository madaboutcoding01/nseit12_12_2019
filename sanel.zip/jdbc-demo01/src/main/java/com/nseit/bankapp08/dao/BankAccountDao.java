package com.nseit.bankapp08.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class BankAccountDao implements IBankAccountDaO<BankAccount>{
	
	private static final String ADD_ACCOUNT = "insert into bankaccount"
			+ " values(?,?,?,?)";
	private static final String FIND_ALL = "SELECT "
			+ " ACCNO,ACCNAME,BALANCE,ACCTYPE "
			+ " FROM BANKACCOUNT";

	public boolean addAccount(BankAccount account) throws Exception {
		Connection connection=ConnectionUtil.getConnection();
		PreparedStatement insert=connection.prepareStatement(ADD_ACCOUNT);
		insert.setInt(1, account.getAccNo());
		insert.setString(2, account.getAccName());
		insert.setDouble(3, account.getBalance());
		if(account instanceof SavingAccount){
			insert.setString(4, "SA");
		}else if(account instanceof SalaryAccount){
			insert.setString(4, "SAL");
		}
		int noOfRecords=insert.executeUpdate();
		insert.close();
		connection.close();
		if(noOfRecords>0){
			System.out.println(noOfRecords+" added ");
			return true;
		}		
		return false;
	}

	public boolean delete(BankAccount account) throws Exception {
Connection connection=ConnectionUtil.getConnection();
		
		connection.close();
		return false;
	}

	public boolean updateDeposit(BankAccount account, double amount) throws Exception {
Connection connection=ConnectionUtil.getConnection();
		
		connection.close();
		return false;
	}

	public boolean updateWitdraw(BankAccount account, double amount) throws Exception {
Connection connection=ConnectionUtil.getConnection();
		
		connection.close();
		return false;
	}

	public boolean closeAccount(int accNo) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	public List<BankAccount> findAll() throws Exception {
		Connection connection=ConnectionUtil.getConnection();
		Statement select=connection.createStatement();
		ResultSet results=select.executeQuery(FIND_ALL);
		BankAccount account=null;
		List<BankAccount> accounts=new ArrayList<BankAccount>();
		
		while(results.next()){
			final String accName=results.getString("accName");
			final double balance=results.getDouble("balance");
			if(results.getString("ACCTYPE").equals("SA")){
				account=new SavingAccount(accName,balance);
			}else if(results.getString("ACCTYPE").equals("SAL")){
				account=new SalaryAccount(accName,balance);
			}
			accounts.add(account);
			
		}
		connection.close();
		return accounts;
	}

	public BankAccount findById(int accNO) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
