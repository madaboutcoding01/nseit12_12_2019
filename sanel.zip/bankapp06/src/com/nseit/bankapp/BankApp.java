package com.nseit.bankapp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.service.BankAccountService;

public class BankApp {

	public static void main(String[] args) {
		BankAccountService service=new BankAccountService();
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
			String choice = "";
			while (true) {
				System.out.println("Select below Options");
				System.out.println("1.Open account");
				System.out.println("2.Get account details");
				System.out.println("3.Deposit");
				System.out.println("4.Withdraw");
				System.out.println("5.Check Balance");
				System.out.println("6.Close account");
				System.out.println("7.Show all Accounts");
				choice = reader.readLine();
				int accNo = 0;
				double amount;
				switch (choice) {
				case "1":
					System.out.println("Enter name ");
					String accName = reader.readLine();
					System.out.println("Enter opening balance");
					double balance = Double.parseDouble(reader.readLine());
					System.out.println(service.addAccount(accName, balance));
					break;
				case "2":
					System.out.println("Ener accNO");
					accNo = Integer.parseInt(reader.readLine());
					BankAccount account=service.findByAccNo(accNo);
					System.out.println(account);
					break;
				case "3":

					System.out.println("Ener accNO");
					accNo = Integer.parseInt(reader.readLine());
					System.out.println("Enter amount");
					amount= Double.parseDouble(reader.readLine());
					System.out.println(service.transaction(accNo, amount, "d"));
					break;
				case "4":
					System.out.println("Ener accNO");
					accNo = Integer.parseInt(reader.readLine());
					System.out.println("Enter amount");
					amount= Double.parseDouble(reader.readLine());
					System.out.println(service.transaction(accNo, amount, "w"));
					break;
				case "5":
					System.out.println("Ener accNO");
					accNo = Integer.parseInt(reader.readLine());
					System.out.println(service.checkBalance(accNo));	
					break;
				case "6":

					System.out.println("Ener accNO");
					accNo = Integer.parseInt(reader.readLine());
					System.out.println(service.closeAccount(accNo));
					break;
				case "7":
					List<BankAccount> accountList = service.getAccounts();
					for(BankAccount ba: accountList){
						System.out.println(ba);
					}
					break;

				}
		System.out.println("Press any key to continue [Press q to exit]");
			if(reader.readLine().equalsIgnoreCase("q")){
				break;
			}
			}

		} catch (Exception e) {
			System.out.println("Reader Error: " + e.getMessage());
		}


	}

}
