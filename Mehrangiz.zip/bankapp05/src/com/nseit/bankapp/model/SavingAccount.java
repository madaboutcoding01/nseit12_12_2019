package com.nseit.bankapp.model;

import com.nseit.bankapp.util.InsufficientBalanceException;

public class SavingAccount extends BankAccount {
	private static final double MIN_BALANCE = 10000.00;

	// alt+s+c
	public SavingAccount() {
		super();
	}

	public SavingAccount(int accNo, String accName, double balance) {
		super(accNo, accName, balance);
	}

	

	public SavingAccount(String accName, double balance) {
		super(accName, balance);
	}

	public double withdraw(double amount) throws InsufficientBalanceException {
		// 50000-35000=15000>10000->ALLOWED
		// 50000-45000=5000>10000->NOT ALLOWED
		double diff = getBalance() - amount;
		if (diff >= MIN_BALANCE) {
			setBalance(diff);
		} else {
			// System.out.println("Witdraw not allowed. Must keep minbalance 10000");
			// System.exit(0);
throw new InsufficientBalanceException("Witdraw not allowed. Must keep minbalance 10000");
		}

		return this.getBalance();
	}

}
