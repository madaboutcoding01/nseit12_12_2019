package com.nseit.productinventory;

import com.nseit.productinventory.service.productServices;

public class productInventoryApp {
	productServices stack=new productServices(5);
}
