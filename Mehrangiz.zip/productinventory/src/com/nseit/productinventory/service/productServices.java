package com.nseit.productinventory.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.productinventory.model.Product;

public class productServices<AnyType> {
	private ArrayList<AnyType> buffer=new ArrayList<>();
	private List<Product> plist=new LinkedList<>();
	private int top=-1;
	private int size=0;
	
	public productServices(int size) {
		super();
		this.buffer=new ArrayList<>();
		this.size = size;
	}
	
	public int getCountOFTotalProduct(){
		return buffer.size();
	}
	
	public String addProduct(AnyType addp)
	{
		if(buffer.add(addp)){
			top++;
			size=getCountOFTotalProduct();
			return "Successfully added the Product";			
		}
		return "Failed to add Product";
	}
	
	public Product findByProductId(int ppid)
	{
		for(Product pid:plist)
		{
			if(pid.getPid()==ppid)
			{
				return pid;
			}
		}
		return null;
	}
}
