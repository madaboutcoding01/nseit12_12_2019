package com.nseit.bankapp.dao;

import java.util.List;

import com.nseit.bankapp.model.BankAccount;

public interface IbankAccountDao<T> {

	boolean addAccount(T account);

	BankAccount getAccountByAccNo(int accNo);

	List<T> getAllAccounts();

}
