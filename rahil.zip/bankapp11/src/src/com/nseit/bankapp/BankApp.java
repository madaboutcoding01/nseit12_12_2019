package src.com.nseit.bankapp;

import java.io.BufferedReader;
import src.com.nseit.bankapp.service.*;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.service.*;

public class BankApp {

	private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String USERNAME = "nseitDB";
	private static final String PASSWORD = "root";

	public static void main(String[] args) {

		try {
			Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			if (connection.isClosed()) {

				System.out.println("failed");

			} else {

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
