package com.nseit.bankapp.service;

public interface IBankAccountService {

	String addAccount(String accName, double balance);

	String getAllaccounts();
	
}
