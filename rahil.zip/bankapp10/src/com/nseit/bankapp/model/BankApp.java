package com.nseit.bankapp.model;

public class BankApp {

	public static void main(String[] args) {

		// BankAccountStack<BankAccount> stack = new BankAccountStack<>(5);
		// stack.addaccount(new SavingAccount("rahil", 10000));
		// stack.addaccount(new SavingAccount("ali", 10000));
		// stack.addaccount(new SalaryAccount("kamani", 0.00));
		// stack.addaccount(new SalaryAccount("amit", 100.00));
		//
		// System.out.println(stack.getallaccount());
		// stack.closeAccount(stack.getaccounts().get(3));
		// System.out.println("after removal ");
		// System.out.println(stack.getallaccount());

	}

}
