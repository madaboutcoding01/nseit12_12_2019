package com.nseit.bankapp.model;

import com.nseit.bankapp.service.IBankAccountService;

public class SavingAccount implements IBankAccountService {

	@Override
	public String addAccount(String accName, double balance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAllaccounts() {
		// TODO Auto-generated method stub
		return null;
	}

}
