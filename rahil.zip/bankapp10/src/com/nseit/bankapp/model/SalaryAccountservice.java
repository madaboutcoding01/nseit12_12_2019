package com.nseit.bankapp.model;

import com.nseit.bankapp.service.IBankAccountService;

public class SalaryAccountservice implements IBankAccountService {

	private BankAccountStack<SalaryAccount> accounts;

	public SalaryAccountservice() {
		super();
	}

	@Override
	public String addAccount(String accName, double balance) {

		String msg = "failed to create acoount";
		msg = accounts.addaccount(new SalaryAccount(accName, balance));

		return msg;
	}

	@Override
	public String getAllaccounts() {
		return accounts.getallaccount();

	}

}
