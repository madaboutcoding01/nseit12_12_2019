package com.nseit.bankapp.model;

import java.util.ArrayList;
import java.util.List;

//BankAccount Stack <T>
public class BankAccountStack<Anytype> {

	private ArrayList<Anytype> list = new ArrayList<Anytype>();
	private int size;
	private int top = -1;

	public BankAccountStack() {
		super();
	}

	public BankAccountStack(int size) {
		super();
		this.list = new ArrayList<>();
		this.size = size;
	}

	public String addaccount(Anytype accont) {

		if (list.add(accont)) {

			top++;
			size = getCountoftotalAccount();
			return "successfully created";

		}

		return "failed to add account";
	}

	public int getCountoftotalAccount() {

		return list.size();

	}

	public String closeAccount(Anytype account) {

		if (list.remove(account)) {

			top--;
			size = getCountoftotalAccount();

			return "account removed";

		}

		return "failed to remove";

	}

	public String getallaccount() {

		StringBuffer buffer = new StringBuffer();
		for (Anytype a : list) {

			buffer.append(a.toString()).append("\n");

		}
		return buffer.toString();

	}

	public List<Anytype> getaccounts() {

		return list;

	}

}
