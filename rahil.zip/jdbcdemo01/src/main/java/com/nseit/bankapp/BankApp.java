package com.nseit.bankapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.nseit.bankapp.service.SavingAccountService;

public class BankApp {

	private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String USERNAME = "nseitDB";
	private static final String PASSWORD = "root";

	public static void main(String[] args) {

//		dummy();
		SavingAccountService service = new SavingAccountService();
		try {
			service.addAccount("Rahil", 99999.00);
			service.findAll().forEach((a)->{
				System.out.println(a);
			});
		} catch (Exception e) {
	
			e.printStackTrace();
		}
	}

	private static void dummy() {
		try {
			Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			if (connection.isClosed()) {

				System.out.println("failed");

			} else {

				System.out.println("success");

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

}
