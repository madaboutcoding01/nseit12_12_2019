package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccount;

public interface IBankAccountService {

	String addAccount(String accName,double balance);
	double checkBalance(int accno);
	BankAccount findByAccNo(int accNo);
	BankAccount[] showAllAccounts();//Natural order
	BankAccount[] showAllByAccName();//AccName Asc
	BankAccount[] showAllByBalance();//Balance Desc
	
	
}

//by default every method is public abstract
//to import related classes ctrl+shift+o