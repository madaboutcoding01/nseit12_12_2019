package src.com.nseit.bankapp.service;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.SortByBalance;
import com.nseit.bankapp.service.SortByName;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankAccountService implements IBankAccountService {

	// private List<BankAccount> accountList = new LinkedList<>();

	private Set<BankAccount> accountList = new HashSet<BankAccount>();

	// findByAccNo
	@Override
	public BankAccount findByAccNo(int accNo) {
		for (BankAccount account : accountList) {
			if (account.getAccNo() == accNo) {
				return account;
			}
		}
		return null;
	}

	// show all accounts
	@Override
	public Set<BankAccount> getAccounts() {
		return accountList;
	}

	// sort by accName
	@Override
	public Set<BankAccount> sortByAccName() {

		SortedSet<BankAccount> sortedSet = new TreeSet<>(new SortByName());

		for (BankAccount ba : accountList) {

			sortedSet.add(ba);

		}

		return sortedSet;
	}

	// sort by balance
	@Override
	public Set<BankAccount> sortByBal() {
		SortedSet<BankAccount> sortedSet2 = new TreeSet<>(new SortByBalance());

		for (BankAccount ba : accountList) {

			sortedSet2.add(ba);

		}

		return sortedSet2;
	}

	// checkBalance
	@Override
	public double checkBalance(int accNo) {
		return findByAccNo(accNo).getBalance();
	}

	// addAccount
	@Override
	public String addAccount(String accName, double balance) {
		boolean test = accountList.add(new SavingAccount(accName, balance));

		if (test)
			return "Account created";
		return "Failed to Create new account";
	}

	// close account
	@Override
	public String closeAccount(int accNo) {
		BankAccount account = findByAccNo(accNo);
		if (accountList.remove(account)) {
			return "Closed account " + account;
		}
		return "Failed to close account";
	}

	// Transaction
	@Override
	public String transaction(int accNo, double amount, String opType) {
		BankAccount account = findByAccNo(accNo);
		String msg = accNo + " ";
		switch (opType) {
		case "d":
			try {
				msg = msg + amount + " amount cretedited.Balance is " + account.deposit(amount);
			} catch (Exception e) {
				msg = "Transaction failed for deposit";
			}
			break;
		case "w":
			try {
				msg = msg + amount + " amount debited.Balance is " + account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg = "Transaction failed for withdraw";
			}

			break;
		}
		return msg;
	}
}
