package com.nseit.inventory.model;

public class Product 
{
	private int pId;
	private String pName;
	private int price;
	private int quantity;
	private static int counter;
	
	public Product() 
	{
		super();
	}
	static{
		counter=1000;
	}
	{
		this.pId=++counter;
	}
	public Product(int pId, String pName, int price, int quantity) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.price = price;
		this.quantity = quantity;
	}
	public Product(String pName, int price, int quantity) {
		super();
		this.pName = pName;
		this.price = price;
		this.quantity = quantity;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}

	