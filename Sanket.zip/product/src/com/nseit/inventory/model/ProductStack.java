package com.nseit.inventory.model;

import java.util.ArrayList;

public class ProductStack<AnyType> 
{
	private ArrayList<AnyType> list=new ArrayList<>();
	private int top=-1;
	
	public String addProduct(AnyType products)
	{
		if(list.add(products)){
			top++;
			return "Successfully Added";
		}
		return "Failed to add";
			
	}
}
