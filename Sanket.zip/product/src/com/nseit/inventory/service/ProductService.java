package com.nseit.inventory.service;


import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class ProductService implements IProduct
{
	private ProductStack<Product> products;

	public ProductService() 
	{
		super();
		products=new ProductStack<>();
	}

	@Override
	public String add(String pName, int price, int quantity) {
		
		String msg="Failed to create new account";
		msg=products.addProduct(new Product(pName, price, quantity));
		
		System.out.println(products);
		return msg;
	}
	


}
