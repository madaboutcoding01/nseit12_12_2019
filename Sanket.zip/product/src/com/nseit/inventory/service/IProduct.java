package com.nseit.inventory.service;

public interface IProduct 
{
	String add(String pName, int price, int quantity);
	
}
