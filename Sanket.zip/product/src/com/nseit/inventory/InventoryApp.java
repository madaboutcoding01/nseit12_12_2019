package com.nseit.inventory;

import java.util.Scanner;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;
import com.nseit.inventory.service.ProductService;

public class InventoryApp 
{
	public static void main(String []args)
	{
//		ProductStack<Product> stack=new ProductStack<>();
//		stack.addProduct(new Product(1001,"laptop",200,2));
//		stack.addProduct(new Product(1002,"mobile",300,3));
//		stack.addProduct(new Product(1003,"tablet",400,4));
//		System.out.println("Add product:");
		Scanner sc=new Scanner(System.in);
		ProductService service=new ProductService();		
//		System.out.println("Enter product id");		
//		int pId=Integer.parseInt(sc.nextLine());
		System.out.println("Enter product name");	
		String pName=sc.nextLine();
		System.out.println("Enter product price");
		int price=Integer.parseInt(sc.nextLine());
		System.out.println("Enter product quantity");
		int quantity=Integer.parseInt(sc.nextLine());
		service.add(pName,price, quantity);
		
		
	}
}
