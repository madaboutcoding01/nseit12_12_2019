package com.nseit.inventory.service;

public class AddProduct {

	private String pname;

	private int price;
	private int Quantity;

	@Override
	public String toString() {
		return "AddProduct [pname=" + pname + ", price=" + price + ", Quantity=" + Quantity + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Quantity;
		result = prime * result + ((pname == null) ? 0 : pname.hashCode());
		result = prime * result + price;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddProduct other = (AddProduct) obj;
		if (Quantity != other.Quantity)
			return false;
		if (pname == null) {
			if (other.pname != null)
				return false;
		} else if (!pname.equals(other.pname))
			return false;
		if (price != other.price)
			return false;
		return true;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public AddProduct(String pname, int price, int quantity) {
		super();
		this.pname = pname;
		this.price = price;
		Quantity = quantity;
	}

}
