package com.nseit.inventory.model;

import java.util.ArrayList;
import java.util.List;

import com.nseit.inventory.service.DeleteProduct;

public class ProductStack<AnyType> {

	private ArrayList<AnyType> list = new ArrayList<AnyType>();
	private int size;
	private int top = -1;

	public ProductStack() {

	}

	public String addproduct(AnyType product) {

		if (list.add(product)) {

			top++;
			// size = getCountoftotalAccount();
			return "successfully added product";

		}

		return "failed to add product";
	}

	public String Deleteproduct(DeleteProduct deleteProduct) {

		list.remove(deleteProduct);
		return "product deleted successfully";

	}

	public String Updateproduct(AnyType product) {
		return null;

	}

	public String findproduct(int pid) {
		return null;

	}

	public List<AnyType> findproduct() {
		return list;

	}

}
