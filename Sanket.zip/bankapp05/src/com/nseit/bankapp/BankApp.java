package com.nseit.bankapp;

import java.util.Scanner;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.BankAccountService;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankApp {
	public static void main(String[] args) {
		// oldMenu();
		BankAccountService accountService = new BankAccountService();
		// 1. ShowAllAccounts
		// showAccountsByAccNo(accountService);
		// showAccountsByAccName(accountService);
		// showAccountsByBalance(accountService);
		// 2. Add new Acccount
		Scanner sc = new Scanner(System.in);
		// createAccount(accountService, sc);
		// 3. Transactions :deposit,withdraw,checkbalance
		BankAccount[] accounts = accountService.getAccounts();
		pritnAccountArray(accounts);
		System.out.println("Enter Account number");
		int accNo = Integer.parseInt(sc.nextLine());
		BankAccount account = accountService.findByAccNo(accNo);
		System.out.println("Enter amount for Deposit");
		double dAmount = Double.parseDouble(sc.nextLine());
		System.out.println(accountService.transaction(accNo, dAmount, "d"));
		System.out.println("Enter amount to be withdraw");
		double wAmount = Double.parseDouble(sc.nextLine());
		System.out.println(accountService.transaction(accNo, wAmount, "w"));
		//check balance		
		System.out.println("Current Balance is : "+accountService.checkBalance(accNo));
		sc.close();

	}

	private static void createAccount(BankAccountService accountService, Scanner sc) {
		System.out.println("Enter name:");
		String accName = sc.nextLine();

		System.out.println("Enter balance:");
		double balance = Double.parseDouble(sc.nextLine());

		String msg = accountService.addAccount(accName, balance);
		System.out.println(msg);
	}

	private static void showAccountsByBalance(BankAccountService accountService) {
		BankAccount[] accounts = accountService.showAllByBalance();
		System.out.println("Account Details Sorty By Balance-DESC");
		pritnAccountArray(accounts);
	}

	private static void showAccountsByAccName(BankAccountService accountService) {
		BankAccount[] accounts = accountService.showAllByAccName();
		System.out.println("Account Details Sorty By AccName-ASC");
		pritnAccountArray(accounts);
	}

	private static void showAccountsByAccNo(BankAccountService accountService) {
		BankAccount[] accounts = accountService.showAllAccounts();
		System.out.println("Account Details Sorty By AccNo-ASC");
		pritnAccountArray(accounts);
	}

	private static void pritnAccountArray(BankAccount[] accounts) {
		for (BankAccount account : accounts) {
			if (account != null) {
				System.out.println(account);
			}

		}
	}

	private static void oldMenu() {
		BankAccount account = null;
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Select options:");
			System.out.println("1. Create Account");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			int mainMenu = Integer.parseInt(sc.nextLine());
			double amount = 0.0;
			switch (mainMenu) {
			case 1:
				System.out.println("Select Type of Account");
				System.out.println("1 Saving Account");
				System.out.println("2 Salary Account");
				int accType = Integer.parseInt(sc.nextLine());
				// System.out.println("Enter your accno");
				// int accNo=Integer.parseInt(sc.nextLine());
				System.out.println("Enter your acc holder name");
				String accName = sc.nextLine();
				System.out.println("Enter opening balance");
				double balance = Double.parseDouble(sc.nextLine());
				switch (accType) {
				case 1:
					account = new SavingAccount(accName, balance);
					break;
				case 2:
					account = new SalaryAccount(accName, balance);
					break;
				}
				break;
			case 2:
				System.out.println("Enter amount to be deposited");
				amount = Double.parseDouble(sc.nextLine());
				try {
					account.deposit(amount);
				} catch (Exception e) {
					System.out.println("While Deposit call");
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter amount to be withdraw");
				amount = Double.parseDouble(sc.nextLine());
				try {
					account.withdraw(amount);
				} catch (InsufficientBalanceException e) {
					System.out.println("While Withdraw call");
					e.printStackTrace();
				}
				break;
			}
			System.out.println("Account Details :");
			System.out.println(account);
			System.out.println("To Exit enter 0");
			int exitLoop = Integer.parseInt(sc.nextLine());
			if (exitLoop == 0)
				break;
		}
	}

}