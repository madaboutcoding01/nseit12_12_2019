package com.nseit.bankapp.model;
//BankAccountStack<T>
//T,E,K,V,N

import java.util.ArrayList;
import java.util.List;

public class BankAccountStack<AnyType>
{
	private ArrayList<AnyType> buffer=new ArrayList<>();
	private int size=0;
	private int top=-1;
	public BankAccountStack() 
	{
		super();
	}
	public BankAccountStack(int size) 
	{
		super();
		this.buffer=new ArrayList<>(size);
		this.size = size;
	}
	public String addAccount(AnyType account)
	{
		if(buffer.add(account))
		{
			top++;
			size=getCountOfTotalAccount();
			return "SUcessfully Added";
			}
		return "Failed to add account";
	}
	public int getCountOfTotalAccount()
	{
			return buffer.size();	
	}
	public String closeAccount(AnyType account)
	{
			if(buffer.remove(account))
			{
				top--;
			size=getCountOfTotalAccount();
			return "Account Closed";
			}
			return "Failed to Close Account";
	}
	public String getAccountDetails()
	{
		StringBuilder sb=new StringBuilder();
		for(AnyType a:buffer)
		{
			sb.append(a.toString()).append("\n");
		}
		return sb.toString();
	}
	public List<AnyType> getAccounts()
	{
		return buffer;
	}
	
}
