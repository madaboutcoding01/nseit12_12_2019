package com.nseit.bankapp.model;

public interface IBankAccountService {
	String addAccount(String accName,double balance);
	
	

}
