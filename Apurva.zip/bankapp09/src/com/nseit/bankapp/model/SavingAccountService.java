package com.nseit.bankapp.model;

public class SavingAccountService implements IBankAccountService{

	private BankAccountStack<SavingAccount> accounts;
	
	public SavingAccountService()
	{
		super();
		accounts=new BankAccountStack<>();
	}
	public String addAccount(String accName,double balance)
	{
		String msg="Failed to create new account";
	}
			
}
