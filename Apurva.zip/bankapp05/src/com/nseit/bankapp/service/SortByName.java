package com.nseit.bankapp.service;

import java.util.Comparator;

import com.nseit.bankapp.model.BankAccount;

public class SortByName implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		BankAccount ba1=(BankAccount)o1;
		BankAccount ba2=(BankAccount)o2;
		return ba1.getAccName().compareTo(ba2.getAccName());
	}

}
