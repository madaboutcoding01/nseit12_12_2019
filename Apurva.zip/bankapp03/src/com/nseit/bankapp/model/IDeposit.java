package com.nseit.bankapp.model;

public interface IDeposit {

	public  double deposit(double amount) throws Exception;
}
