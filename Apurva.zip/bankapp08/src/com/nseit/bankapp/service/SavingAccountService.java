package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SavingAccount;

public class SavingAccountService implements IBankAccountService{

	private BankAccountStack<SavingAccount> accounts;
	
	public SavingAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}

	@Override
	public String addAcount(String accName, double balance) {
		String msg="Failed To create new account ";
		msg=accounts.addAccount(new SavingAccount(accName, balance));		
		return msg;
	}

	@Override
	public String getAllAccountDetails() {
		// TODO Auto-generated method stub
		return accounts.getAccountDetails();
	}

	
}
