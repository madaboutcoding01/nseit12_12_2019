package com.nseit.inventory.service;

public class IProduct {

	private int productid;
	private String pname;
	private double price;
	private int quantity;

	public IProduct()
	{}
	
	public IProduct(int productid,String pname,double price,int quantity)
	{
		super();
		this.productid = productid;
		this.pname = pname;
		this.price = price;
		this.quantity = quantity;
		
		
	}
}
