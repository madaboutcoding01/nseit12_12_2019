package com.nseit.inventory.service;

public class DeleteProduct {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "DeleteProduct [name=" + name + "]";
	}

	public DeleteProduct(String name) {
		super();
		this.name = name;
	}


}
