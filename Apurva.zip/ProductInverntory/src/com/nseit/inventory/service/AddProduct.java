package com.nseit.inventory.service;

public class AddProduct {
	private String pname;
	
	private int price;
	private int Quantity;
	
	@Override
	public String toString() {
		return "AddProduct [pname=" + pname + ", price=" + price + ", Quantity=" + Quantity + "]";
	}
	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public AddProduct(String pname, int price, int quantity) {
		super();
		this.pname = pname;
		this.price = price;
		Quantity = quantity;
	}

	

}
