package com.nseit.bankapp.Dao;

public interface IBankAccountDao {

}
