package com.nseit.bankapp.service;

public class IBankAccountService {

}
