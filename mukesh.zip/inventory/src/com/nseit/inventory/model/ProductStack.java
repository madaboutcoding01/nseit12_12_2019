package com.nseit.inventory.model;

import java.util.ArrayList;

import com.nseit.inventory.service.AddProduct;
import com.nseit.inventory.service.DeleteProduct;

public class ProductStack<AnyType> {
	private ArrayList<AnyType> buffer = new ArrayList<>();
	

	public String addProduct(AnyType product) {
		if (buffer.add(product)) {
			
			return "Successfully added Product";

		}
		return "failed to add Product";
	}

	public ProductStack() {
		super();
		
	}

	public void addproduct(AddProduct addProduct) {
		
		
	}

	public void Deleteproduct(DeleteProduct deleteProduct) {
		
		
	}

	public Object findproduct() {
		
		return null;
	}
}