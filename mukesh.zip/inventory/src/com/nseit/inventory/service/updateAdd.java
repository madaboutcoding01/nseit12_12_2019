package com.nseit.inventory.service;

public class updateAdd {
	public updateAdd(int pid,int quantity) {
		
	}
}
