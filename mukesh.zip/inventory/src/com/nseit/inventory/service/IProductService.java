package com.nseit.inventory.service;

public interface IProductService {
	String addProduct(String productName, int price, int quantity);
	String delProduct(String productid);
	String updateAdd(String productid, int quantity);
	String updateRemove(String productid, int quantity);
	
	String getProductDetails();
}
