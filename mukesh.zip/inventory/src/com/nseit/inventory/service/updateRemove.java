package com.nseit.inventory.service;

public class updateRemove {
	public updateRemove(int pid,int quantity) {
		
	}
}
