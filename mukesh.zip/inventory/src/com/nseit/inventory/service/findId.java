package com.nseit.inventory.service;

public class findId {
	public findId(int pid) {
		
	}
}
