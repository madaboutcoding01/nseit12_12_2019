package com.nseit.inventory.service;

public class DeleteProduct {

	public DeleteProduct(String name) {
		
	}

}
