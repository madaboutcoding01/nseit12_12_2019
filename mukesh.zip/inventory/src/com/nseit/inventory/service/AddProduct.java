package com.nseit.inventory.service;

public class AddProduct {

	public AddProduct(String pname, int price, int quantity) {
		
	}

}
