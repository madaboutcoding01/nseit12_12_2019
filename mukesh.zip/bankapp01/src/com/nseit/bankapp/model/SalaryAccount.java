package com.nseit.bankapp.model;

public class SalaryAccount extends BankAccount {

	public SalaryAccount() {
		super();	
	}
	public SalaryAccount(int accNo, String accName, double balance) {
		super(accNo, accName, balance);
	}
	public double withdraw(double amount) {
		double diff=this.getBalance()-amount;
		if(diff>0){
			this.setBalance(diff);
		}else{
			System.out.println("Insufficient Balance .");
			System.exit(0);
		}
		return this.getBalance();
	}

}
