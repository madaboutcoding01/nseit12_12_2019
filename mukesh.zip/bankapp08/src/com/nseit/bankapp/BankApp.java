package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.IBankService;
import com.nseit.bankapp.service.SalaryAccountService;
import com.nseit.bankapp.service.SavingAccountService;

public class BankApp {

	public static void main(String[] args){
		//testBankAccountStack();
		IBankService service=new SavingAccountService();
		service.addAccount("Mukesh",10000);
		System.out.println(service.getAccountDetails());
		
		service=new SalaryAccountService();
		service.addAccount("Mk",10000);
		System.out.println(service.getAccountDetails());
		
	}

	private static void testBankAccountStack() {
		BankAccountStack<BankAccount> stack=new BankAccountStack<>(5);
		stack.addAccount(new SavingAccount("Rajat",10000));
		stack.addAccount(new SavingAccount("Raju",1000));
		stack.addAccount(new SalaryAccount("Raj",0.0));
		stack.addAccount(new SalaryAccount("jatin",41000));
		
		System.out.println(stack.getAccountDetails());
		stack.closeAccount(stack.getAccounts().get(3));
		System.out.println("After Closure");
		System.out.println(stack.getAccountDetails());
	}
}
