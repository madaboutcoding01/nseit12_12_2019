package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class SavingAccountService implements IBankService {
	private BankAccountStack<SavingAccount> accounts;

	public SavingAccountService() {
		super();
		accounts = new BankAccountStack<>();
	}

	@Override
	public String addAccount(String accName, int balance) {
		String msg = "Failed to create new account";
		msg=accounts.addAccount(new SavingAccount(accName,balance));
		return msg;
	}
	@Override
	public String getAccountDetails() {
		// TODO Auto-generated method stub
		return accounts.getAccountDetails();
	}
}
