package com.nseit.bankapp.service;

public interface IBankService {
	String addAccount(String accName, int balance);

	String getAccountDetails();

}
