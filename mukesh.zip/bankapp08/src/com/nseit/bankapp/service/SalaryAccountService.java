package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;

public class SalaryAccountService implements IBankService
{
	private BankAccountStack<SalaryAccount> accounts=new BankAccountStack<>();
	public SalaryAccountService()
	{
		super();
		accounts=new BankAccountStack<>();
	}
	@Override
	public String addAccount(String accName, int balance){
		String msg="Failed to create new account";
		msg=accounts.addAccount(new SalaryAccount(accName,balance));
		return msg;
	}
	@Override
	public String getAccountDetails() {
		// TODO Auto-generated method stub
		return accounts.getAccountDetails();
	}
}
