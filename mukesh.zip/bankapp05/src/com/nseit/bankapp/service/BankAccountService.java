package com.nseit.bankapp.service;

import java.util.Arrays;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankAccountService implements IBankAccountService {
	private BankAccount []accountArray=new BankAccount[5];
	private int top=0;	
	public BankAccountService() {
		super();
		accountArray[0]=new SavingAccount("Amit",   10000.00);
//		accountArray[1]=new SavingAccount("Sumit",  11000.00);
//		accountArray[2]=new SavingAccount("Ranjit", 15000.00);
//		accountArray[3]=new SavingAccount("Atit",  100000.00);
//		accountArray[4]=new SavingAccount("Ankit",  14000.00);
		
	}

	public String addAccount(String accName, double balance) {
		BankAccount account=new SavingAccount(accName, balance);
		if(top<accountArray.length){
			top++;
			accountArray[top]=account;
			
		}else{
			return "Account creation failed!";
		}
		
		return "Account Created : \n"+account;
	}

	public double checkBalance(int accNo) {
		BankAccount account =findByAccNo(accNo);
		return account.getBalance();
	}

	public BankAccount findByAccNo(int accNo) {
		BankAccount account=null;
		for(BankAccount ba : accountArray){
			if(ba!=null&& ba.getAccNo()==accNo){
				account=ba;
			}
		}
		return account;
	}

	public BankAccount[] showAllAccounts() {
		Arrays.sort(accountArray);//comparable		
		return accountArray;
	}

	public BankAccount[] showAllByAccName() {
		Arrays.sort(accountArray,new SortByName());
		return accountArray;
	}

	public BankAccount[] showAllByBalance() {
		Arrays.sort(accountArray,new SortByBalance());
		return accountArray;
	}

	public BankAccount[] getAccounts() {
		return accountArray;
	}

	public String transaction(int accNo,double amount,String opType)
	{   BankAccount account=findByAccNo(accNo);
		String msg="";
		switch(opType)
		{
			case "d":
				try{
				msg = accNo+" credited by "+amount+". Current Balance is "+account.deposit(amount);
				}catch(Exception e)
				{msg="Transaction Failed"+e.getMessage();}
				break;
				
			case "w":
				
			try {
				msg = accNo+" debited by "+amount+". Current Balance is "+account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg="Transaction Failed"+ e.getMessage();
			}
				break;
		}
		
		return msg;
	}
}
