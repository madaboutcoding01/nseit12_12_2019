package com.nseit.inventory.util;

public class CustomException extends Exception
{

}
