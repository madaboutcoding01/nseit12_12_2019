package com.nseit.inventory.service;

import java.util.List;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class ProductService implements IProduct
{
	private ProductStack<Product> product;

	@Override
	public String add(int pid,String pname, int price, int quantity) {
		String msg="Failed To Create New Account";
		msg=product.add(new Product(pid,pname,price,quantity));
		return msg;
	}

	@Override
	public int delete(int pid) {
	
		return 0;
	}

	@Override
	public int updateAdd(int pid, int quantity) {
	
		return 0;
	}

	@Override
	public int updateRemove(int pid, int quantity) {
	
		return 0;
	}

	@Override
	public int findId(int pid) {
		
		return 0;
	}

	@Override
	public List<Product> findAll() {
		return product.findAll();
	}
	
}
