package com.nseit.inventory.service;

import java.util.List;

import com.nseit.inventory.model.Product;

public interface IProduct 
{
	public String add(int pid,String pname,int price,int quantity);
	public int delete(int pid);
	public int updateAdd(int pid,int quantity);
	public int updateRemove(int pid,int quantity);
	public int findId(int pid);
	public List<Product> findAll();
}
