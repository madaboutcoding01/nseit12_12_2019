package com.nseit.inventory;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class InventoryApp {

	public static void main(String[] args) 
	{
		ProductStack<Product> stack=new ProductStack<>(5);
		
		stack.add(new Product(1001,"Phone",20000,3));
		stack.add(new Product(1002,"Bike",20000,1));
		stack.add(new Product(1002,"Bike",20000,1));
		stack.add(new Product(1002,"Bike",20000,1));
		
		System.out.println("Number of Product Added");
		System.out.println(stack.getCountOFTotal());
		System.out.println("Find All");
		System.out.println(stack.findAll());
		
		System.out.println("Find By Id");
		System.out.println(stack.findById(1001));
		
		System.out.println("After Deletion Of Product");
		stack.delete(1001);
		System.out.println(stack.findAll());
		
	}

}
