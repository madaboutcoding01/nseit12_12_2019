package com.nseit.bankapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil
{
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String USERNAME = "nseitDB1";
	private static final String PASSWORD = "root";
	
	
	private static Connection connection;
	static Connection getConnection()throws Exception
	{
		connection=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		if(!connection.isClosed())
		{
			return connection;
		}
		else
		{
			System.out.println("Failed To Connect");
		}
		return null;
	}

}
