package com.nseit.bankapp.service;

import java.util.List;

import com.nseit.bankapp.dao.BankAccountDao;
import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;

public class SavingAccountService implements IBankAccountService{

	private BankAccountDao dao;
	
	
	public SavingAccountService() {
		super();
		dao=new BankAccountDao();
	}

	public String addAccount(String accName, double balance) throws Exception
	{
		SavingAccount account=new SavingAccount(accName,balance);
		if(dao.addAccount(account))
		{
			return account+" Created";
		}
		return "Account Creation Failed";
	}

	public Object findById(int accNo) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BankAccount> findAll() {
		
		return null;
	}
	

}
