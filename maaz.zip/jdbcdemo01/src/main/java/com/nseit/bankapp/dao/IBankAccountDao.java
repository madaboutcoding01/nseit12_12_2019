package com.nseit.bankapp.dao;

import java.util.List;

public interface IBankAccountDao<T> 
{
	boolean addAccount(T account) throws Exception;
	boolean delete(T account)throws Exception;
	boolean updatedeposit(T account,double amount)throws Exception;
	boolean updatewithdraw(T account,double amount)throws Exception;
	boolean closeAccount(int accNo)throws Exception;
	List<T> findAll() throws Exception;
	T findById(int accNo)throws Exception;
}
