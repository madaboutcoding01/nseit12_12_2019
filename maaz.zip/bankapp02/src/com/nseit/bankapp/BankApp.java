package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// try {
		BankAccount account = new SavingAccount(1001, "Manisha", 50000.00);
		System.out.println(account);
		System.out.println("Witdhraw 10000 from saving account");
		try {
			System.out.println("Current available balance "
					+ account.withdraw(10000));
		} catch (InsufficientBalanceException e) {
			System.out.println("TryCatch -1 ");
			e.printStackTrace();
		}
		BankAccount salaryAccount = new SalaryAccount(1002, "Manisha", 50000.00);
		System.out.println(salaryAccount);
		System.out.println("Witdhraw 10000 from salary account");
		try {
			System.out.println("Current available balance "
					+ salaryAccount.withdraw(10000));
		} catch (InsufficientBalanceException e) {
			System.out.println("TryCatch -2 ");
			e.printStackTrace();
		}
		System.out.println("Witdhraw 45000 from saving account");
		try {
			System.out.println("Current available balance "
					+ account.withdraw(45000));
		} catch (InsufficientBalanceException e) {
			System.out.println("TryCatch -3 ");
			e.printStackTrace();
		}
		System.out.println("Witdhraw 45000 from salary account");
		try {
			System.out.println("Current available balance "
					+ salaryAccount.withdraw(45000));
		} catch (InsufficientBalanceException e) {
			System.out.println("TryCatch -4 ");
			e.printStackTrace();
		}
		// } catch (InsufficientBalanceException e) {
		// e.printStackTrace();
		// }

	}

}
