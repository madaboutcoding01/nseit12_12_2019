package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.IBankService;

public class SavingAccountService implements IBankService{

	
	private BankAccountStack<SavingAccount> accounts;
	
	
	public SavingAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}


	@Override
	public String addAccount(String accName, double balance) {
		String msg="Failed To Create New Account";
		msg=accounts.addAccount(new SavingAccount(accName,balance));
		return msg;
	}


	@Override
	public String getAllAccountDetails() {
		return accounts.getAccountDetails();
	}

}
