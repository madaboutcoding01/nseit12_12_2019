package com.nseit.bankapp.service;

public interface IBankService 
{
	public String addAccount(String accName,double balance);
	public String getAllAccountDetails();
}
