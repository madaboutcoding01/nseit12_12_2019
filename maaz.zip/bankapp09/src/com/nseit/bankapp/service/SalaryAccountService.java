package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.IBankService;

public class SalaryAccountService implements IBankService{

	private BankAccountStack<SalaryAccount> accounts;
	
	
	
	public SalaryAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}

	@Override
	public String addAccount(String accName, double balance) {
		String msg="Failed To Create New Account";
		msg=accounts.addAccount(new SalaryAccount(accName,balance));
		return msg;
	}

	@Override
	public String getAllAccountDetails() {
		return accounts.getAccountDetails();
	}

}
