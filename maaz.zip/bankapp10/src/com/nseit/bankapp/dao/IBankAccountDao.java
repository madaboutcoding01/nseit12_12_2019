package com.nseit.bankapp.dao;

import java.util.List;

import com.nseit.bankapp.model.BankAccount;

public interface IBankAccountDao<T> {

	boolean addAccount(T account);
	T getAccountByAccNo(int accNo);
	List<T> getAllAccounts();
	
}
