package com.nseit.bankapp.service;

import java.util.List;

import com.nseit.bankapp.model.BankAccount;

public interface IBankAccountService {

	String addAccount(String accName,double Balance);
	double checkBalance(int accNo);
	String transaction(int accNo,double amount,String accType);
	List<BankAccount> getAccounts();
	List<BankAccount> sortByAccName();
	List<BankAccount> sortByBal();
	BankAccount findByAccNo(int accNo);
	String closeAccount(int accNo);
}
