package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class SalaryAccountService implements IBankService {

	private BankAccountStack<SalaryAccount> accounts;
	
	
	public SalaryAccountService() {
		super();
		accounts = new BankAccountStack<>();
	}


	@Override
	public String addAccount(String accName, double balance) {
		// TODO Auto-generated method stub
		return null;
	}

	}