package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SavingAccount;

public class SavingAccountService implements IBankService {

	private BankAccountStack<SavingAccount> accounts;
	
	
	public SavingAccountService() {
		super();
		accounts = new BankAccountStack<>();
	}


	@Override
	public String addAccount(String accName, double balance) {
		String msg="Failed to create new Account";
		msg=accounts.addAccount(new SavingAccount(accName, balance));
		return msg;
	}

	public String getAllAccountDetails()
	{
		return null;
		
	}
}