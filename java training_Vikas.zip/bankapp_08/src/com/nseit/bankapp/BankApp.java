package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.IBankService;
import com.nseit.bankapp.service.SalaryAccountService;
import com.nseit.bankapp.service.SavingAccountService;

public class BankApp {

	public static void main(String[] args) {

		IBankService service =  new SavingAccountService();
		service.addAccount("Virat",25000);
		System.out.println(service.getAllAccountDetails());

		service = new SalaryAccountService();
				service.addAccount("Vikas",10000);
		System.out.println(service.getAllAccountDetails());
	}
}
		/*// TODO Auto-generated method stub
		BankAccountStack<BankAccount> stack = new BankAccountStack<>(5);
		stack.addAccount(new SavingAccount("Rachel", 10000));
		stack.addAccount(new SavingAccount("Monica", 20000));
		stack.addAccount(new SavingAccount("Pheobe", 25000));
		stack.addAccount(new SalaryAccount("Joey", 1000));
		stack.addAccount(new SalaryAccount("Chandler", 300000));
		stack.addAccount(new SalaryAccount("Ross", 45000));

		System.out.println(stack.getAccountDetails());
		stack.closeAccount(stack.getAccounts().get(4));
		System.out.println("After Closure");
		System.out.println(stack.getAccountDetails());*/

