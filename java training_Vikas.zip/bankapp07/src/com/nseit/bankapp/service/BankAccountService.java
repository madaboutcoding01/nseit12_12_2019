package com.nseit.bankapp.service;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankAccountService implements IBankAccountService{
	private Set<BankAccount> accountSet = new HashSet<>();

	@Override
	public String addAccount(String accName, double balance) {
		boolean test = accountSet.add(new SavingAccount(accName, balance));
		if (test)
			return "Account created";
		return "Failed to Create new account";
	}

	@Override
	public double checkBalance(int accNo) {
		return findByAccNo(accNo).getBalance();
	}

	@Override
	public String transaction(int accNo, double amount, String opType) {
		BankAccount account = findByAccNo(accNo);
		String msg = accNo + " ";
		switch (opType) {
		case "d":
			try {
				msg = msg + amount + " amount credited.Balance is " + account.deposit(amount);
			} catch (Exception e) {
				msg = "Transaction failed for deposit";
			}
			break;
		case "w":
			try {
				msg = msg + amount + " amount debited.Balance is " + account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg = "Transaction failed for withdraw";
			}

			break;
		}
		return msg;
	}

	@Override
	public Set<BankAccount> getAccounts() {
		return accountSet;
	}

	@Override
	public Set<BankAccount> sortByAccName() {
		SortedSet<BankAccount> sortedSet = new TreeSet<>(new SortByName());
		for(BankAccount ba:accountSet)
		{
			sortedSet.add(ba);
		}
		return sortedSet;
	}

	@Override
	public Set<BankAccount> sortByBal() {
		SortedSet<BankAccount> sortedSet = new TreeSet<>(new SortByBalance());
		for(BankAccount ba:accountSet)
		{
			sortedSet.add(ba);
		}
		return sortedSet;
	}

	@Override
	public BankAccount findByAccNo(int accNo) {
		for (BankAccount account : accountSet) {
			if (account.getAccNo() == accNo) {
				return account;
			}
		}
		return null;
	}

	@Override
	public String closeAccount(int accNo) {
		BankAccount account = findByAccNo(accNo);
		if (accountSet.remove(account)) {
			return "Closed account " + account;
		}
		return "Failed to close account";
	}
	
	
}
