package com.nseit.inventory.service;

import java.util.Set;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class ProductService implements IProductService{

	private ProductStack<Product> products;
	@Override
	public String addname(String pname, double price, int quantity) {
		return null;
	}

	@Override
	public String delete(int pid) {
		String msg="Failed to delete Product";
		return null;
	}

	@Override
	public String updateAdd(int pid, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateRemove(int pid, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int find(int pid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Set<ProductStack> getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
