package com.nseit.inventory.service;

import java.util.Set;

import com.nseit.inventory.model.ProductStack;

public interface IProductService {
String addname(String pname,double price,int quantity);
String delete(int pid);
String updateAdd(int pid,int quantity);
String updateRemove(int pid,int quantity);
int find(int pid);
Set<ProductStack> getProducts();

}
