package com.nseit.inventory.model;

import java.util.ArrayList;

public class ProductStack<AnyType> {
	private ArrayList<AnyType> buffer = new ArrayList<>();
	private int size=0;
	private int top=-1;
	public ProductStack() {
		super();
	}
	public ProductStack(int size) {
		super();
		this.buffer = new ArrayList<>(size);
		this.size = size;
	}
	//add product
public String addProduct(AnyType product)
{
	if(buffer.add(product))
	{
		top++;
		size=getCountOfTotalProduct();
		return "Successfully added";
	}
	return "Failed to add Product";
}
//delete product
public String deleteProduct(AnyType pid)
{
	ArrayList<AnyType> id = findId(pid);
	if(buffer.remove(pid))
	{
		top--;
		size=getCountOfTotalProduct();
		return "product Successfully deleted";
	}
	return null;
}
//update product
public String updateProduct(AnyType product)
{
	
	return null;
	
}
//find pid
public ArrayList<AnyType> findId(AnyType pid)
{
//	for(AnyType product:buffer)
//	{
//		if(buffer.getID == pid)
//		{
//			return buffer;
//		}
//	}
	return null;
	
}
//findAll..

public int getCountOfTotalProduct() {
	return buffer.size();
}
	
}
