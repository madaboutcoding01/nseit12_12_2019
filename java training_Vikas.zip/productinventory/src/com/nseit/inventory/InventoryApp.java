package com.nseit.inventory;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;
import com.nseit.inventory.service.ProductService;

public class InventoryApp {

	public static void main(String[] args) {
	ProductService service = new ProductService();
	service.addname("Monitor",15000.00,2);
	System.out.println(service.getProducts());
	}
}
