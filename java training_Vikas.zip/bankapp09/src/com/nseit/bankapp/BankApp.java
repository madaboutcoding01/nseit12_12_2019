package com.nseit.bankapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BankApp {
	
private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
private static final String USERNAME="nseitdb";
private static final String PASSWORD="root";

public static void main(String[] args) {
	try {
		Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		if(con.isClosed()){
			System.out.println("Failed");
		}else{
			System.out.println("success");
		}
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}	
}
}
