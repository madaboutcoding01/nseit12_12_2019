package com.nseit.productapp.service;

public interface IProduct {
	String addProduct(String productName, double productPrice, double productQty);
	String deleteProduct(int productId);
	String updateProductAdd(int productId, double productQty);
	String updateProductRemove(int productId, double productQty);

}


/*
add(pname,price,quantity),
delete(pid),
updateAdd(pid,quantity),
updateRemove(pid,quantity),
findId(pid),
findAll():products*/