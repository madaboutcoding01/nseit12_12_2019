package com.nseit.bankapp.model;

public class BankAccount {
	private int accNo;
	private String accName;
	private double balance;
	
	public BankAccount(){}
	public BankAccount(int accNo, String accName, double balance) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.balance = balance;
	}
	
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName
				+ ", balance=" + balance + "]";
	}
	
	
}
//alt+s+c: default constructor
//alt+s+a: overloaded constructor
//alt+s+r: getter setter
//alt+s+s+s: toString



