package com.nseit.bankapp.dao;

import java.util.List;

public interface IBankAccountDao<T> {
	
	boolean addAccount(T account);
	T getAccountByAccNo(int accNo);
	List<T> getAllAccounts();
	
}
