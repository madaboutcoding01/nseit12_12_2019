package com.nseit.bankapp.dao;

public class BankAccountDao {

}
