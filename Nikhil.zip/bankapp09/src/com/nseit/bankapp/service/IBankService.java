package com.nseit.bankapp.service;

import com.nseit.bankapp.model.BankAccount;

public interface IBankService {
	String addAccount(String accName,double balance);
	BankAccount findByAccNo(int accNo);

}
