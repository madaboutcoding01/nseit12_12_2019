package com.nseit.bankapp.service;

import java.util.HashSet;
import java.util.Set;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class SalayAccountService implements IBankAccountService{
	
	
	private BankAccountStack<SalaryAccount> account;
			
	public SalayAccountService() {
		super();
		account
		// TODO Auto-generated constructor stub
	}
	
	

}
