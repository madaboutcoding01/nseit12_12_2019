package com.nseit.bankapp.service;

import java.util.HashSet;
import java.util.Set;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.BankAccountStack;
import com.nseit.bankapp.model.SavingAccount;

public class SavingAccountService implements IBankAccountService {


	BankAccountStack<BankAccount> stack=
			new BankAccountStack<>();
	
	
	public String addAccount(String accName, double balance) {
		boolean test = stack.add(new SavingAccount(accName, balance));
		if (test)
			return "Account created";
		return "Failed to Create new account";
	}
}
