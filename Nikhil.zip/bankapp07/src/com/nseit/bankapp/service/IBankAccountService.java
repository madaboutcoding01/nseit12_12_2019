package com.nseit.bankapp.service;

import java.util.List;
import java.util.Set;

import com.nseit.bankapp.model.BankAccount;

public interface IBankAccountService {
	
	String addAccount(String accName,double balance);
	double checkBalance(int accNo);
	String transaction(int accNo,double amount,String accType);
	Set<BankAccount> getAccounts();
	Set<BankAccount> sortByAccName();
	Set<BankAccount> sortByBal();
	BankAccount findByAccNo(int accNo);
	String closeAccount(int accNo);
	
	

}
