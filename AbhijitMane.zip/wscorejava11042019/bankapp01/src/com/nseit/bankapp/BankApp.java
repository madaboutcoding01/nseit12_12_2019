package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;

public class BankApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		BankAccount account=new SavingAccount(1001, "Manisha", 50000.00);
		System.out.println(account);

		System.out.println("Witdhraw 10000 from saving account");
		System.out.println("Current available balance "+account.withdraw(10000));


		BankAccount salaryAccount=new SalaryAccount(1002, "Manisha", 50000.00);
		System.out.println(salaryAccount);

		System.out.println("Witdhraw 10000 from salary account");
		System.out.println("Current available balance "+salaryAccount.withdraw(10000));



		System.out.println("Witdhraw 45000 from saving account");
		System.out.println("Current available balance "+account.withdraw(45000));
		System.out.println("Witdhraw 45000 from salary account");
		System.out.println("Current available balance "+salaryAccount.withdraw(45000));

	
	}

}
