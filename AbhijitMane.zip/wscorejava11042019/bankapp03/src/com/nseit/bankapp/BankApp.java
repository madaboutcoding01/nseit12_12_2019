package com.nseit.bankapp;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class BankApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		BankAccount account = new SavingAccount(1001, "Manisha", 50000.00);
		try {
			System.out.println(account);
			System.out.println("Witdhraw 10000 from saving account");
			System.out.println(account.withdraw(10000));
			System.out.println("Deposit 10000 from saving account");
			System.out.println(account.deposit(10000));
		} catch (InsufficientBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		account = new SalaryAccount(1001, "Manisha", 50000.00);
		try {
			System.out.println(account);
			System.out.println("Witdhraw 10000 from saving account");
			System.out.println(account.withdraw(10000));
			System.out.println("Deposit 10000 from saving account");
			System.out.println(account.deposit(10000));
		} catch (InsufficientBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
