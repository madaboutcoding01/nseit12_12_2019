import com.nseit.app.Greeting;
public class MyApp{
//method to start application execution
public static void main(String []args){
	//Object of Greeting
	Greeting greeting=new Greeting();
	String message=greeting.greet();
	System.out.println(message);
}
}