package com.nseit.bankapp.service;

import java.util.List;

import com.nseit.bankapp.model.BankAccount;

public interface IBankAccountService {
	String addAccount(String accname, double balance);
	double checkBalance(int accNo);
	String transaction(int accNo, double amount, String accType);
	List<BankAccount> getAccounts();
	List<BankAccount> sortByaccName();
	List<BankAccount> sortByBal();
	BankAccount findByAccNo(int accNo);
	String closeAccount(int accNo);
}
