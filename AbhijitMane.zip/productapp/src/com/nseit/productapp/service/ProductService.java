package com.nseit.productapp.service;

public class ProductService implements IProduct {

	@Override
	public String addProduct(String productName, double productPrice, double productQty) {
//		Product product=new Product(productName, productPrice, productQty);
//		if(top<accountArray.length){
//			top++;
//			accountArray[top]=account;
//			
//		}else{
//			return "Account creation failed!";
//		}
//		
		return "Account Created : \n";
	}

	@Override
	public String deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateProductAdd(int productId, double productQty) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateProductRemove(int productId, double productQty) {
		// TODO Auto-generated method stub
		return null;
	}

}
