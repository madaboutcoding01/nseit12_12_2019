package com.nseit.productapp.model;

import java.util.ArrayList;
import java.util.List;


public class ProductStack<AnyType> {
	
	
	private ArrayList<AnyType> buffer=new ArrayList<>();
	private int size=0;
	private int top=-1;
	public ProductStack() {
	}
	public ProductStack(int size) {
		super();
		this.buffer=new ArrayList<>(size);
		this.size = size;
	}
	
	public String addProduct(AnyType product)
	{
		if(buffer.add(product)){
			top++;
			size=getCountOFTotalAccount();
			return "Successfully added";
			}
		return "Failed to add account";
	}
	private int getCountOFTotalAccount() {
		return buffer.size();
	}
	
	public String getAccountDetails(){
		StringBuilder sb=new StringBuilder();
		for(AnyType a:buffer){
			sb.append(a.toString())
			.append("\n");
		}
		return sb.toString();
	}
	
	public List<AnyType> getAccount(){
		return buffer;
	}
	public String closeAccount(AnyType account)
	{
		if(buffer.remove(account)){
			top--;
			size=getCountOFTotalAccount();
			return "Account Closed";
		}
		return "Failed to close account";
	}
//	public String Deleteproduct(DeleteProduct deleteProduct) {
//
//		buffer.remove(deleteProduct);
//		return "product deleted successfully";
//
//	}
	
	
	

}
