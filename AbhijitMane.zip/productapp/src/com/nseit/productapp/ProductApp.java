package com.nseit.productapp;




import java.util.Scanner;

import com.nseit.productapp.model.Product;
import com.nseit.productapp.model.ProductStack;

public class ProductApp {

	public static void main(String[] args) {
		ProductStack<Product> stack=new ProductStack<>(5);
		stack.addProduct(new Product(1001,"Laptop",50000.0,10));
		stack.addProduct(new Product(1001,"Mobile",10000.0,19));
		stack.addProduct(new Product(1001,"TV",21000.0,17));
		stack.addProduct(new Product(1001,"AC",55000.0,8));
		
		
		System.out.println(stack.getAccountDetails());
		stack.closeAccount(stack.getAccount().get(3));
		System.out.println("After closure");
		System.out.println(stack.getAccountDetails());
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter product id");
		int productId=Integer.parseInt(sc.nextLine());
		System.out.println("Enter product Name");
		String productName=sc.nextLine();
		System.out.println("Enter product Price");
		Double productPrice=Double.parseDouble(sc.nextLine());
		System.out.println("Enter product Quantity");
		int productQty=Integer.parseInt(sc.nextLine());
		
		System.out.println(stack.getAccountDetails());
}
}