package com.nseit.bankapp.service;

import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.mpdel.BankAccountStack;

public class SalaryAccountService implements IBankAccountService{
private BankAccountStack<SalaryAccount> accounts;
	
	public SalaryAccountService() {
		super();
	}
	
	@Override
	public String addAccount(String accName, double balance) {
		String msg="Failed to create new account";
		msg=accounts.addAccount(new SalaryAccount(accName, balance));
		return msg;
	}
	public String getAccountDeatils()
	{
		return accounts.getAccountDetails();
	}
	

}
