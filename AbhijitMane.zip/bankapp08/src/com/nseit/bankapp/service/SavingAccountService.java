package com.nseit.bankapp.service;


import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.mpdel.BankAccountStack;
import com.nseit.bankapp.service.IBankAccountService;

public class SavingAccountService implements IBankAccountService{
	private BankAccountStack<SavingAccount> accounts;
	
	public SavingAccountService() {
		super();
	}
	
	@Override
	public String addAccount(String accName, double balance) {
		String msg="Failed to create new account";
		msg=accounts.addAccount(new SavingAccount(accName, balance));
		
		return msg;
	}
	public String getAccountDeatils()
	{
		return accounts.getAccountDetails();
	}
	
}
