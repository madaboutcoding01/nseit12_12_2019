package com.nseit.bankapp.service;

import java.util.List;

import com.nseit.bankapp.model.BankAccount;

public interface IBankAccountService {
	String addAccount(String accName, double balance);
	String getAccountDeatils();
	
}
