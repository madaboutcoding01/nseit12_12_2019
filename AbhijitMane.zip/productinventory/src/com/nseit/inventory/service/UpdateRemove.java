package com.nseit.inventory.service;

public class UpdateRemove {

	private int pid;
	private int quantity;

	@Override
	public String toString() {
		return "UpdateRemove [pid=" + pid + ", quantity=" + quantity + "]";
	}

	public UpdateRemove(int pid, int quantity) {
		super();
		this.pid = pid;
		this.quantity = quantity;
	}

}
