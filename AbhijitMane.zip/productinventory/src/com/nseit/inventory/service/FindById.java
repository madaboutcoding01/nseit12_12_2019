package com.nseit.inventory.service;

public class FindById {

	private int pid;

	public FindById(int pid) {
		super();
		this.pid = pid;
	};

}
