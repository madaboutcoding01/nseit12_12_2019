package com.nseit.inventory.service;

public class UpdateAdd {

	private int pid;
	private int quantity;

	@Override
	public String toString() {
		return "UpdateAdd [pid=" + pid + ", quantity=" + quantity + "]";
	}

	public UpdateAdd(int pid, int quantity) {
		super();
		this.pid = pid;
		this.quantity = quantity;
	}

}
