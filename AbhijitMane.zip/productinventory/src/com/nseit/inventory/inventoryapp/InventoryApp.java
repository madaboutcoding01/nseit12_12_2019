package com.nseit.inventory.inventoryapp;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.nseit.inventory.model.ProductStack;
import com.nseit.inventory.service.AddProduct;
import com.nseit.inventory.service.DeleteProduct;

public class InventoryApp {

	public static void main(String[] args) {

		while (true) {

			Scanner sc = new Scanner(System.in);

			ProductStack stack = new ProductStack();

			System.out.println("please select from this options");
			System.out.println("1.addproduct");
			System.out.println("2.deleteallproduct");
			System.out.println("3.getallproduct");
			int choice = Integer.parseInt(sc.nextLine());

			switch (choice) {
			case 1:

				System.out.println("enter product name");
				String pname = sc.nextLine();
				System.out.println("enter price");
				int price = Integer.parseInt(sc.nextLine());
				System.out.println("enter quantity");
				int quantity = Integer.parseInt(sc.nextLine());

				stack.addproduct(new AddProduct(pname, price, quantity));
				System.out.println("product added successfully");
				System.out.println(stack.findproduct());

				break;
			case 2:

				System.out.println("enter product name");
				String name = sc.nextLine();
				stack.Deleteproduct(new DeleteProduct(name));
				System.out.println("product remove successfully");

				break;
			case 3:

				System.out.println(stack.findproduct().toString());

			}

		}
	}

}
