package com.nseit.bankapp.service;

import java.util.Set;

import com.nseit.bankapp.model.BankAccount;


public interface IBankAccountService {
	String addAccount(String accname, double balance);
	double checkBalance(int accNo);
	String transaction(int accNo, double amount, String accType);
	Set<BankAccount> getAccounts();
	Set<BankAccount> sortByaccName();
	Set<BankAccount> sortByBal();
	BankAccount findByAccNo(int accNo);
	String closeAccount(int accNo);
}

