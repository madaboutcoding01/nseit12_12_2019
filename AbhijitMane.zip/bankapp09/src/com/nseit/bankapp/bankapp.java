package com.nseit.bankapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SalaryAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.mpdel.BankAccountStack;

public class bankapp {

	private static final String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String user = "nseitDB";
	private static final String password = "root";

	public static void main(String[] args) {
		try {
			Connection con=DriverManager.getConnection(url,user,password);
			if(con.isClosed()){
				System.out.println("Failed");
			}else{
				System.out.println("success");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
