package com.nseit.bankapp.dao;

import java.util.List;

public class BankAccountDao implements IBankAccountDao{

	@Override
	public boolean addAccount(Object account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object getAccountByAccNo(int accNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
