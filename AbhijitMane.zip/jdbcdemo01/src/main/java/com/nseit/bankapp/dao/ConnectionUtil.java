package com.nseit.bankapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil {
	private static final String url = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String user = "system";
	private static final String password = "root";
	
	private static Connection connection;
	public static Connection getConnection() throws Exception{
		connection=DriverManager.getConnection(url,user,password);
		if(!connection.isClosed()){
			return connection;
		}
		else{
			System.out.println("Failed to connect");
		}
		return null;
	}
}
