package com.nseit.bankapp.service;

import java.util.List;

import com.nseit.bankapp.dao.BankAccountDao;
import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;

public class SavingAccountService implements IBankAccountService{
	private BankAccountDao dao;
	public SavingAccountService() {
		super();
		dao=new BankAccountDao();
	}
	public String addAccount(String accName, double balance) throws Exception {
		SavingAccount account=new SavingAccount(accName, balance);
		if(dao.addAccount(account)){
			return account+" created. ";
		}
		return "account creation failed";
	}

	public SavingAccount findById(int accNo)throws Exception {
		return null;
	}

	public List<BankAccount>  findAll()throws Exception {
		return dao.findAll();
	}
	
	
}
