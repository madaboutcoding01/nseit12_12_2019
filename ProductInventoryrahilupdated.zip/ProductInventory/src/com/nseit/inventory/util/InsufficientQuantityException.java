package com.nseit.inventory.util;

public class InsufficientQuantityException extends Exception{
	
	public InsufficientQuantityException(String msg){
		super(msg);
	}

}
