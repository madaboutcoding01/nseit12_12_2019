package com.nseit.inventory.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetConnection {

	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/rahil";
	static final String USER = "root";
	static final String PASS = "root";

	public static Connection getconnection() throws ClassNotFoundException, SQLException {

		Connection con = null;

		Class.forName("com.mysql.jdbc.Driver");

		con = DriverManager.getConnection(DB_URL, USER, PASS);

		return con;
	}

}
