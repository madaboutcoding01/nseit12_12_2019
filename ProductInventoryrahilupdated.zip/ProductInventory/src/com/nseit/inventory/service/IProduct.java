package com.nseit.inventory.service;

public interface IProduct {

	String add(int pid, String pname, double price, int quantity);

	int delete(String name);

	int update(int pid, String pname, double price, int quantity);

	int findId(int pid);

	String findAll();

}
