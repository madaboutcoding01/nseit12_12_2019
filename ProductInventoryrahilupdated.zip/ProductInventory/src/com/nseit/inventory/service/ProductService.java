package com.nseit.inventory.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductService implements IProduct {

	@Override
	public String add(int pid, String pname, double price, int quantity) {

		try {
			PreparedStatement pr = GetConnection.getconnection()
					.prepareStatement("insert into product values(?,?,?,?)");
			pr.setInt(1, pid);
			pr.setString(2, pname);
			pr.setDouble(3, price);
			pr.setInt(4, quantity);

			pr.executeUpdate();

			System.out.println("data inserted success fullyv in database");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public int delete(String name) {

		try {

			PreparedStatement pr = GetConnection.getconnection().prepareStatement("delete from product where pname=?");
			pr.setString(1, name);
			pr.executeUpdate();

		} catch (Exception e) {

			System.out.println(e);

		}

		return 0;
	}

	@Override
	public int update(int pid, String pname, double price, int quantity) {

		try {
			PreparedStatement pr = GetConnection.getconnection()
					.prepareStatement("update product set quantity=? and pname=? and price=? where pid=?");
			pr.setInt(1, quantity);
			pr.setString(2, pname);
			pr.setInt(3, pid);

			pr.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public int findId(int pid) {

		try {

			PreparedStatement pr = GetConnection.getconnection().prepareStatement("select * from product where pid=?");
			pr.setInt(1, pid);

			ResultSet rs = pr.executeQuery();

			while (rs.next()) {

				System.out.println(rs.getString("pname"));
				System.out.println(rs.getInt("pid"));
				System.out.println(rs.getDouble("pprice"));
				System.out.println(rs.getInt("quantity"));

			}

		} catch (Exception e) {
			System.out.println(e);
		}

		return 0;
	}

	@Override
	public String findAll() {

		try {

			PreparedStatement pr = GetConnection.getconnection().prepareStatement("select * from product");

			ResultSet rs = pr.executeQuery();
			while (rs.next()) {

				System.out.println(rs.getString("pname"));
				System.out.println(rs.getInt("pid"));
				System.out.println(rs.getDouble("pprice"));
				System.out.println(rs.getInt("quantity"));

			}

		} catch (Exception e) {
			System.out.println(e);
		}

		return null;
	}

}
