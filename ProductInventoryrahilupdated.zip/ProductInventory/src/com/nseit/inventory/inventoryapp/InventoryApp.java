package com.nseit.inventory.inventoryapp;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.Product.*;
import com.nseit.inventory.model.ProductStack;
import com.nseit.inventory.service.ProductService;

public class InventoryApp {

	public static void main(String[] args) {

		ProductService service = new ProductService();
		Scanner sc = new Scanner(System.in);

		System.out.println("Welcome To Product Inventory ");
		System.out.println("1.using collections");
		System.out.println("2.using jdbc");
		int selection = Integer.parseInt(sc.nextLine());

		if (selection == 2) {

			while (true) {

				ProductService service2 = new ProductService();

				System.out.println("please select from this options");
				System.out.println("1.addproduct");
				System.out.println("2.deleteproductusingname");
				System.out.println("3.update product");
				System.out.println("4.getproductusingid");
				System.out.println("5.getallproduct");
				int choice = Integer.parseInt(sc.nextLine());

				switch (choice) {
				case 1:

					System.out.println("enter product id");
					int productid = Integer.parseInt(sc.nextLine());
					System.out.println("enter product name");
					String pname = sc.nextLine();
					System.out.println("enter price");
					double price = Double.parseDouble(sc.nextLine());
					System.out.println("enter quantity");
					int quantity = Integer.parseInt(sc.nextLine());
					// stack.add(new AddProduct(productid, pname, price, quantity));
					// ;
					service2.add(productid, pname, price, quantity);

					System.out.println("product added successfully");
					// System.out.println(stack.findproduct());

					break;
				case 2:

					System.out.println("enter product name");
					String name = sc.nextLine();
					// stack.Deleteproduct(new DeleteProduct(name));
					service2.delete(name);
					System.out.println("product remove successfully");

					break;
				case 3:

					System.out.println("enter price");
					double proprice = Integer.parseInt(sc.nextLine());
					System.out.println("enter name of the product");
					String proname = sc.nextLine();
					System.out.println("enter pid to be updated ");
					int pid = Integer.parseInt(sc.nextLine());
					System.out.println("enter quantity to be updated ");
					int quantity2 = Integer.parseInt(sc.nextLine());
					// stack.Updateproduct(product);
					service2.update(pid, proname, proprice, quantity2);
					System.out.println("product updated successfully");

					break;
				case 4:

					System.out.println("enter pid");
					int pid2 = Integer.parseInt(sc.nextLine());
					service2.findId(pid2);

					// String msg = stack.findproduct(pid2);

					// System.out.println(msg);

					break;
				case 5:

					service2.findAll();

					break;

				}

			}

		} else {

			while (true) {

				ProductStack stack = new ProductStack();

				System.out.println("please select from this options");
				System.out.println("1.addproduct");
				System.out.println("2.deleteproduct");
				// System.out.println("3.update product");
				System.out.println("3.getallproduct");
				int choice = Integer.parseInt(sc.nextLine());

				switch (choice) {
				case 1:

					System.out.println("enter product id");
					int productid = Integer.parseInt(sc.nextLine());
					System.out.println("enter product name");
					String pname = sc.nextLine();
					System.out.println("enter price");
					double price = Double.parseDouble(sc.nextLine());
					System.out.println("enter quantity");
					int quantity = Integer.parseInt(sc.nextLine());

					String res = stack.addAccount(new Product(productid, pname, price, quantity));
					System.out.println(res);
					// System.out.println("product added successfully");

					break;

				case 2:

					System.out.println("enter product name");
					String pname2 = sc.nextLine();

					stack.deleteAccount(pname2);

					break;

				case 3:

					List<Product> Productlist = stack.showallproduct();

					System.out.println(Productlist);

					for (Product ba : Productlist) {

						System.out.println(ba);

					}

					break;

				default:
					break;
				}

			}

		}
	}
}
