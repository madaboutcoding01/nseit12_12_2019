package com.nseit.inventory.model;

import java.util.List;
import java.util.Set;

public interface IProductService {

	String addAccount(Product product);

	String deleteAccount(String name);

	List<Product> showallproduct();

//	Product findByAccNo(int accNo);

	// String closeAccount(int accNo);

}
