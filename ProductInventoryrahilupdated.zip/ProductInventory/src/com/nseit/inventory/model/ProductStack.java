package com.nseit.inventory.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class ProductStack implements IProductService {

	private List<Product> accountList = new ArrayList<Product>();

	@Override
	public String addAccount(Product product) {

		if (accountList.add(product)) {

			return "product added successfully";

		}

		return "failed to add product";
	}

	@Override
	public String deleteAccount(String name) {

		accountList.remove(name);

		return null;
	}

	@Override
	public List<Product> showallproduct() {

		return accountList;
	}

}
