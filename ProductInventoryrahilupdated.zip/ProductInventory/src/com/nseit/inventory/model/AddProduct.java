package com.nseit.inventory.model;

public class AddProduct {

	private int pid;
	private String pname;
	private double pprice;
	private int quantity;

	public AddProduct() {
		super();
	}

	public AddProduct(int pid, String pname, double pprice, int quantity) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pprice = pprice;
		this.quantity = quantity;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public double getPprice() {
		return pprice;
	}

	public void setPprice(int pprice) {
		this.pprice = pprice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "AddProduct [pid=" + pid + ", pname=" + pname + ", pprice=" + pprice + ", quantity=" + quantity + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + pid;
		result = prime * result + ((pname == null) ? 0 : pname.hashCode());
		result = (int) (prime * result + pprice);
		result = prime * result + quantity;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddProduct other = (AddProduct) obj;
		if (pid != other.pid)
			return false;
		if (pname == null) {
			if (other.pname != null)
				return false;
		} else if (!pname.equals(other.pname))
			return false;
		if (pprice != other.pprice)
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}

}
