package com.nseit.inventory.service;

public interface ProductService {
	
}
