package com.nseit.inventory;

public class InventoryApp {

}
