package com.nseit.inventory.model;

import com.nseit.inventory.service.ProductService;

public class ProductStack implements ProductService{
	
	private void addProduct(int productid,String pname,double price, int quantity){
		System.out.println("product added as ID="+productid+" name "+pname+" price "+price+" quantity "+quantity);
		
	}
	private void deleteProduct(int productid){
		
		System.out.println("product added as "+productid);	
	}

public static void main(String args[]){
		
		ProductStack p = new ProductStack();
		
		p.addProduct(1000, "table", 1000, 10);
		}
	
}
