package com.nseit.bankApp.service;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedSet;
import java.util.Set;
import java.util.Set;

import com.nseit.bankapp.model.BankAccount;
import com.nseit.bankapp.model.SavingAccount;
import com.nseit.bankapp.service.SortByBalance;
import com.nseit.bankapp.service.SortByName;
import com.nseit.bankapp.util.InsufficientBalanceException;

public class bankAppSevice implements IBankAccountService{

private Set<BankAccount> accountSet =new Set<BankAccount>() {
	
	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public Iterator<BankAccount> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public boolean addAll(Collection<? extends BankAccount> c) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean add(BankAccount e) {
		// TODO Auto-generated method stub
		return false;
	}
};
	
	@Override
	public BankAccount findByAccNo(int accNo) {
		for (BankAccount account:accountSet){
			if(account.getAccNo()==accNo)
			{
				return account;
			}
		}
		return null;
	}
	
	@Override
	public Set<BankAccount> getAccounts() {
		return accountSet;
	}
	
	@Override
	public Set<BankAccount> sortByAccName() {
		Collections.so(accountSet,new SortByName());
		return accountSet;
	}
	
	@Override
	public Set<BankAccount> sortByBal() {
		Collections.sort(accountSet,new SortByBalance());
		return accountSet;
	}
	
	@Override
	public double checkBalance(int accNo) {
		return findByAccNo(accNo).getBalance();
	}
	
	@Override
	public String addAccount(String accName, double balance) {
		boolean test = 
		accountSet.add(new SavingAccount(accName, balance));
		if(test){
			return "Account Created";
		}
		else
			return "Failed to create account";
	}
	
	@Override
	public String closeAccount(int accNo) {
		BankAccount account = findByAccNo(accNo);
		if(accountSet.remove(account)){
			return "Account Closed"+account;
		}
		return "Failed to close account";
	}
	
	@Override
	public String transaction(int accNo, double amount, String accType) {
		BankAccount account = findByAccNo(accNo);
		String msg=accNo+" ";
		
		String opType = accType;
		switch(opType ){
		case "d":
			try {
				msg = msg + amount + " amount cretedited.Balance is " + account.deposit(amount);
			} catch (Exception e) {
				msg = "Transaction failed for deposit";
			}
			break;
		case "w":
			try {
				msg = msg + amount + " amount debited.Balance is " + account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg = "Transaction failed for withdraw";
			}
			break;
		}
		return null;
	}

	@Override
	public Set<BankAccount> sortByAccounts() {
		// TODO Auto-generated method stub
		return null;
	}
}
