package com.nseit.bankApp.service;

import com.nseit.bankApp.model.BankAccountStack;

public class SalaryAccountService implements IBankAccountService{

	private BankAccountStack<SalaryAccount> accounts;
	
	public SalaryAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}

	@Override
	public String addAcount(String accName, double balance) {
		String msg="Failed To create new account ";
		msg=accounts.addAccount(new SalaryAccount(accName, balance));		
		return msg;
	}

	@Override
	public String getAllAccountDetails() {
		return accounts.getAccountDetails();
	}

	
}
