package com.nseit.bankApp.service;
import java.util.Stack;
import com.nseit.bankApp.model.BankAccountStack;

public class SavingAccountService implements IBankAccountService{

	private BankAccountStack<SavingAccount> accounts;
	
	public SavingAccountService() {
		super();
		accounts=new BankAccountStack<>();
	}

	@Override
	public String addAcount(String accName, double balance) {
		String msg="Failed To create new account ";
		msg=accounts.addAccount(new SavingAccount(accName, balance));		
		return msg;
	}

	@Override
	public String getAllAccountDetails() {
		// TODO Auto-generated method stub
		return accounts.getAccountDetails();
	}

	
}
