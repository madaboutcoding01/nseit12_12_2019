package com.nseit.bankApp.service;

public interface IBankAccountService {

	String addAcount(String accName,double balance);

	String getAllAccountDetails();
}
