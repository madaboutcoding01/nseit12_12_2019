package com.nseit.bankApp.service;

public class SavingAccService implements IbankService{

	
}
