package com.nseit.bankApp.service;

import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class BankAccountService implements IBankAccountService {

	private Set<BankAccountService> accountSet=new HashSet<>();

	public String addAccount(String accName, double balance) {
		boolean test = accountSet.add(new BankAccountService(accName, balance));
		if (test)
			return "Account created";
		return "Failed to Create new account";
	}

	@Override
	public double checkBalance(int accNo) {
		return findByAccNo(accNo).getBalance();
	}

	@Override
	public String transaction(int accNo, double amount, String opType) {
		BankAccount account = findByAccNo(accNo);
		String msg = accNo + " ";
		switch (opType) {
		case "d":
			try {
				msg = msg + amount + " amount cretedited.Balance is " 
			+ account.deposit(amount);
			} catch (Exception e) {
				msg = "Transaction failed for deposit";
			}
			break;
		case "w":
			try {
				msg = msg + amount + " amount debited.Balance is " + account.withdraw(amount);
			} catch (InsufficientBalanceException e) {
				msg = "Transaction failed for withdraw";
			}

			break;
		}
		return msg;
	}

	@Override
	public Set<BankAccount> getAccounts() {
		return accountSet;
	}

	@Override
	public Set<BankAccount> sortByAccName() {
		SortedSet<BankAccount> sortedSet=new TreeSet<>(new SortByName());
		for(BankAccount ba:accountSet){
			sortedSet.add(ba);
		}
		return sortedSet;
	}

	@Override
	public Set<BankAccount> sortByBal() {

		SortedSet<BankAccount> sortedSet=new TreeSet<>(new SortByBalance());
		for(BankAccount ba:accountSet){
			sortedSet.add(ba);
		}
		return sortedSet;
	}

	@Override
	public BankAccount findByAccNo(int accNo) {
		for (BankAccount account : accountSet) {
			if (account.getAccNo() == accNo) {
				return account;
			}
		}
		return null;
	}

	@Override
	public String closeAccount(int accNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addAcount(String accName, double balance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAllAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
