package com.nseit.bankApp.service;

import com.nseit.bankApp.model.BankAccountStack;

public class SalaryAccService implements IbankService{
	private BankAccountStack<SalaryAccount> accounts;
	
	pubilc SalaryAccService(){
		super();
		accounts = new BankAccountStack<>();
	}
	
	
	
}
