package com.nseit.bankApp.service;

public interface IbankService {

}
