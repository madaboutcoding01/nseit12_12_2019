package com.nseit.bankapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class connectioUtil {
	
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String USERNAME= "nseitDB";
	private static final String PASSWROD="root";
	
	private static Connection connection;
	public static Connection getConnection() throws Exception{
		connection=DriverManager.getConnection(URL,USERNAME,PASSWROD);
		
		if(!connection.isClosed()){
			return connection;
		}
		else
		{
			System.out.println("Filed to connect");
		}
		return null;
	}
	
}
