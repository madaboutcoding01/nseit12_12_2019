package com.nseit.bankapp;

import com.nseit.bankapp.service.SavingAccountService;

public class BankApp {
	
	public static void main(String args[]){
		SavingAccountService service = new SavingAccountService();
		service.addAccount("ABC", 1000);
		service.findAll().forEach(a)->;
		
	}

}
