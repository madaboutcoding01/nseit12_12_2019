package com.nseit.inventory;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class InventoryApp {

	public static void main(String[] args) {
		ProductStack<Product> stack = new ProductStack<>(6);
		stack.add(new Product(1001,"abc", 250.0, 10));
		stack.add(new Product(1002,"def", 350.0, 11));
		stack.add(new Product(1003,"ghi", 450.0, 12));
		stack.add(new Product(1004,"jkl", 150.0, 13));

		System.out.println(stack.getProduct());
		stack.delete(stack.getProduct().get(3));
		System.out.println("After deletion");
		System.out.println(stack.getProduct());

	}

}
