package com.nseit.inventory.model;

public class Product {

	private String pname;
	private int quantity;
	private double price;
	private int pid;
	public Product(int pid,String pname,double price,int quantity)
	{
		//super();
		
		this.pname=pname;
		this.price=price;
		this.quantity=quantity;
		this.pid=pid;
	}
	
	
	public String getpname() {
		return pname;
	}

	public void setpname(String pname) {
		this.pname = pname;
	}
	
	public int getquantity() {
		return quantity;
	}

	public void setquantity(int quantity) {
		this.quantity = quantity;
	}
	
	public double getprice() {
		return price;
	}

	public void setprice(double price) {
		this.price = price;
	}
	
	public int getpid() {
		return pid;
	}

	public void setid(int id) {
		this.pid = pid;
	}
	
	public String toString() {
		return "Product [Id=" + pid + "Pname=" + pname + ", Quantity=" + quantity
				+ ", price=" + price + "]" + "\n";
	}
}
