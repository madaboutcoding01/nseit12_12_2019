package com.nseit.inventory.model;

import java.util.ArrayList;
import java.util.List;

public class ProductStack<AnyType> {
	
	private ArrayList<AnyType> buffer=new ArrayList<>();
	private int size=0;
	private int head=-1;
	
	public ProductStack() {
		super();
	}
	public ProductStack(int size) {
		super();
		this.buffer=new ArrayList<>(size);
		this.size = size;
	}
	
	public String add(AnyType product){
		if(buffer.add(product)){
			head++;
			size=getCountOFTotalProduct();
			return "Product Added";			
		}
		return "Failed to add Product";
	}
	
	public int getCountOFTotalProduct(){
		return buffer.size();
	}
	
	public String delete(AnyType product){
		if(buffer.remove(product)){
			head--;
			size=getCountOFTotalProduct();
			return "Product deleted";
		}
		return "Failed to delete account";
	} 
	
	/*public int findId(AnyType product){
		
	}*/
	
	
	public List<AnyType> getProduct(){
		return buffer;
	}
}