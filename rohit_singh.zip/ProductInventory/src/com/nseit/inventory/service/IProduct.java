package com.nseit.inventory.service;

public interface IProduct {
	
	String add(String pname,double price,int quantity);
	int delete(int pid);
	int updateAdd(int pid,int quantity);
	int updateRemove(int pid,int quantity);
	int findId(int pid);
	String findAll();

}
