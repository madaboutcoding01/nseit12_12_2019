package com.nseit.bankapp.service;

import java.util.List;

public interface IBankAccountService<T> {

	String addAccount(String accName,double balance)throws Exception;
	T findById(int accNo)throws Exception;
	List<BankAccount> findAll()throws Exception;
}