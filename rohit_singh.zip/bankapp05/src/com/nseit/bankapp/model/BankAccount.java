package com.nseit.bankapp.model;

import com.nseit.bankapp.util.InsufficientBalanceException;

public abstract class BankAccount implements IBankAccount,Comparable{
	private static int counter;//0
	
	private int accNo;
	private String accName;
	private double balance;
	//init block - static or non-static
	static{
		counter=1000;
	}
	{
		//non static will be called whenever object is crated
		this.accNo=++counter;
	}
	
	public BankAccount(){}
	
	

	public BankAccount(String accName, double balance) {
		super();
		this.accName = accName;
		this.balance = balance;
	}



	public BankAccount(int accNo, String accName, double balance) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.balance = balance;
	}
	
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName
				+ ", balance=" + balance + "]";
	}

	public double deposit(double amount)throws Exception{
		System.out.println("Current Balance before deposit: "+this.balance);
		this.balance=this.balance+amount;
		System.out.println(accNo+" credited with"+amount+". Current Balance"+this.balance);
		return this.balance;
	}
public abstract double withdraw(double amount) throws InsufficientBalanceException;



@Override
public int compareTo(Object o1) {
	BankAccount ba=(BankAccount)o1;
	return this.accNo-ba.accNo;//asc
	//return ba.accNo-this.accNo;//desc
}


}
//alt+s+c: default constructor
//alt+s+a: overloaded constructor
//alt+s+r: getter setter
//alt+s+s+s: toString
//alt+s+v: unimplement


