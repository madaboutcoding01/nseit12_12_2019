package com.nseit.bankapp.service;

public class SavingAccountService implements IBankService {

	@Override
	public String addAccount(String accName, double balance) {
		
		
		return null;
	}

}
