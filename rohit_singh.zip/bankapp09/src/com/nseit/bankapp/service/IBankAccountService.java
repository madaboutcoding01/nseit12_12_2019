package com.nseit.bankapp.service;

public interface IBankAccountService {

}
