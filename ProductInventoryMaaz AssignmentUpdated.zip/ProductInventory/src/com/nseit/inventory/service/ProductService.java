package com.nseit.inventory.service;

import java.util.List;

import com.nseit.inventory.model.Product;
import com.nseit.inventory.model.ProductStack;

public class ProductService implements IProduct
{
	private ProductStack<Product> product;

	@Override
	public boolean add(Product p) {
		
		return false;
	}

	@Override
	public String delete(String name) {
		
		return "Deleted";
	}

	@Override
	public int update(int pid, String pname, double price, int quantity) {
		
		return 0;
	}

	@Override
	public int findId(int pid) {
		
		return 0;
	}

	@Override
	public List<Product> findAll() {
		
		return null;
	}

	
	
}