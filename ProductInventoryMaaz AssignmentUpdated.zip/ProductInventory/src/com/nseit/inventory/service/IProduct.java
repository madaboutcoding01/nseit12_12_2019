package com.nseit.inventory.service;

import java.util.List;

import com.nseit.inventory.model.Product;

public interface IProduct 
{
	public boolean add(Product p);
	public String delete(String name);
	int update(int pid, String pname, double price, int quantity);
	public int findId(int pid);
	public List<Product> findAll();
}