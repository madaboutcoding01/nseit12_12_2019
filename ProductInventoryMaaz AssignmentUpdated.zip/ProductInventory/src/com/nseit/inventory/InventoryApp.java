package com.nseit.inventory;

import java.sql.SQLException;
import java.util.Scanner;

import com.nseit.dao.ProductDao;
import com.nseit.inventory.model.Product;
//import com.nseit.inventory.model.ProductStack;

public class InventoryApp {

	public static void main(String[] args) throws Exception 
	{
		
		ProductDao p1=new ProductDao();
		
		System.out.println("1. Add Product :");
		System.out.println("2.View All Product");
		System.out.println("3.Enter Product Name To Delete:");
		System.out.println("4.For Update :");
		System.out.println("5.Find Product By Id :");
		
		Scanner sc=new Scanner(System.in);
		
		String choice=sc.next();
		switch(choice)
		{

			case "1":
			addMethod(sc, p1);
			break;
	
			case "2":
			p1.findAll();
			break;

			case "3": 
			deleteMethod(sc, p1);
			break;
			
			case "4": 
			updateMethod(sc, p1);
			break;

			case "5": 
			findbyIdMethod(sc, p1);
			break;
		
		}

		/*ProductStack<Product> stack=new ProductStack<>(5);

		stack.add(new Product(1001,"Phone",20000,3));
		stack.add(new Product(1002,"Bike",20000,1));
		stack.add(new Product(1002,"Bike",20000,1));
		stack.add(new Product(1002,"Bike",20000,1));

		System.out.println("Number of Product Added");
		System.out.println(stack.getCountOFTotal());
		System.out.println("Find All");
		System.out.println(stack.findAll());

		System.out.println("Find By Id");
		System.out.println(stack.findById(1001));

		System.out.println("After Deletion Of Product");
		stack.delete(1001);
		System.out.println(stack.findAll());*/




	}

	private static void findbyIdMethod(Scanner sc, ProductDao p1) throws SQLException, Exception {
		System.out.println("Enter Product Id :");
		int ptid2=sc.nextInt();
		p1.findId(ptid2);
	}

	private static void updateMethod(Scanner sc, ProductDao p1) throws SQLException, Exception {
		System.out.println("Enter Product Id :");
		int ptid1=sc.nextInt();
		System.out.println("Enter Product Name :");
		String pname1=sc.next();
		System.out.println("Enter Product Price :");
		int ptprice1=sc.nextInt();
		System.out.println("Enter Product Quantity :");
		int ptQ1=sc.nextInt();

		int count=p1.update(ptid1, pname1, ptprice1, ptQ1);
		System.out.println("Update count "+count);
	}

	private static void deleteMethod(Scanner sc, ProductDao p1) throws SQLException, Exception {
		System.out.println("Enter Product Name");
		String ptname=sc.next();
		p1.delete(ptname);
		p1.findAll();
	}

	private static void addMethod(Scanner sc, ProductDao p1) throws Exception {
		System.out.println("Enter Product Id :");
		int ptid=sc.nextInt();

		System.out.println("Enter Product Name :");
		String pname=sc.next();

		System.out.println("Enter Product Price :");
		int ptprice=sc.nextInt();

		System.out.println("Enter Product Quantity :");
		int ptQ=sc.nextInt();

		p1.add(new Product(ptid,pname,ptprice,ptQ));
	}
}

