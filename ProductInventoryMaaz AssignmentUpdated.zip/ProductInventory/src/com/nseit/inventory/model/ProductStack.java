package com.nseit.inventory.model;

import java.util.ArrayList;
import java.util.List;

public class ProductStack<AnyType>
{
	private List<AnyType> buffer=new ArrayList<>();
	private int size=0;
	private int top=-1;
	
	public ProductStack() 
	{
		super();
	}
	
	public ProductStack(int size) {
		super();
		this.size = size;
	}

	public String add(AnyType p)
	{
		if(buffer.add(p))
		{
			top++;
			size=getCountOFTotal();
			return "SucessFully Added Product";
		}
		return "Failed To Add Product" ;
		
	}

	public int getCountOFTotal() {
		return buffer.size();
	}
	
	public int delete(int pid)
	{
		if(buffer.remove(pid) != null)
		{
			top--;
			size=getCountOFTotal();
			System.out.println("Product Deleted");
			return buffer.size();
		}
		return size;
	}
	
	//public String update(Product p)
	//{
		//return null;
		
	//}
	
	public int findById(int pid)
	{
		return pid;
	}
	
	public List<AnyType> findAll()
	{
		return buffer;
	}

}
