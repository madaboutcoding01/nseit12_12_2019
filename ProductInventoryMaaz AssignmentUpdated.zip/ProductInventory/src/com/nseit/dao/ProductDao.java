package com.nseit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.nseit.inventory.ConnectionUtil;
import com.nseit.inventory.model.Product;

public class ProductDao 
{
	private static final String ADD_ACCOUNT = "insert into product"
			+ " values(?,?,?,?)";
	private static final String FIND_ALL = "SELECT "
			+ " pid,pname,price,quantity "
			+ " FROM product";

	private static final String UPDATE_ACCOUNT ="update product set quantity=?, pname=? , price=? where pid=?";

	private static final String DELETE_PRODUCT="delete from product where pname=?";

	public boolean add(Product p) throws Exception
	{
		Connection connection=ConnectionUtil.getConnection();

		PreparedStatement insert=connection.prepareStatement(ADD_ACCOUNT);

		insert.setInt(1, p.getPid());
		insert.setString(2, p.getPname());
		insert.setInt(3, p.getPrice());
		insert.setInt(4,p.getQuantity());

		int noOfProducts=insert.executeUpdate();
		insert.close();


		if(noOfProducts>0){
			System.out.println(noOfProducts+" Product Added Sucessfully");
			return true;
		}	
		connection.close();
		return false;
	}

	public List<Product> findAll() throws Exception {
		Connection connection=ConnectionUtil.getConnection();
		Statement select=connection.createStatement();
		ResultSet results=select.executeQuery(FIND_ALL);
		Product p=null;
		List<Product> accounts=new ArrayList<Product>();

		while(results.next()){
			int pid=results.getInt("pid");
			String pname=results.getString("pname");
			int price=results.getInt("price");
			int quantity=results.getInt("quantity");
			System.out.println(pid);
			System.out.println(pname);
			System.out.println(price);
			System.out.println(quantity);
			accounts.add(p);

		}
		connection.close();
		return accounts;
	}

	public int update(int pid, String pname, int price, int quantity) throws SQLException, Exception {


		PreparedStatement pr = ConnectionUtil.getConnection().prepareStatement(UPDATE_ACCOUNT);
		pr.setInt(4, pid);
		pr.setString(2, pname);
		pr.setInt(3, price);
		pr.setInt(1,quantity);

		int count=pr.executeUpdate();

		return count>0?count:0;
	}
	public int findId(int pid) throws SQLException, Exception {



		PreparedStatement pr = ConnectionUtil.getConnection().prepareStatement("select * from product where pid=?");
		pr.setInt(1, pid);

		ResultSet rs = pr.executeQuery();

		while (rs.next()) {

			System.out.println(rs.getInt("pid"));
			System.out.println(rs.getString("pname"));
			System.out.println(rs.getInt("price"));
			System.out.println(rs.getInt("quantity"));

		}
		return 0;
	}

	public String delete(String name) throws SQLException, Exception {

		PreparedStatement pr = ConnectionUtil.getConnection().prepareStatement(DELETE_PRODUCT);
		pr.setString(1,name);
		pr.executeUpdate();

		return "Deleted SuccessFully";
	}

}
